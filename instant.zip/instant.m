%% INSTANT Neuronal Spike-Train ANalysis Toolbox 2020-12-16
% This program inputs files of spike timing data, performs
% statistical tests, and estimates model parameters.
%
% *Features:*
%
% * Data input as either spike times or intervals.
% * Automatic detection and choice of most parameters.
% * Automatic cleaning of data, including removal of outliers
%   and non-stationary segments of data.
% * A variety of data correlation and stationarity tests.
% * A choice of different membrane potential models.
% * Estimation of model parameters using global search.
% * Estimation of parameter errors (MSE) using 0.632 bootstrap.
% * INSTANT recomputation of PDF and CDF as parameters are varied
%   manually using slider or edit controls.
% * Saving and loading of parameters on file.
% * Multiple choice of integrators.
% * Parallel processing option if multicores are available.
% * Batch processing for estimation of parameters and errors.
% * Computation of Fisher information and CRLB.
% * Graphics output to PDF.
%
% The source code below is marked up for automatic document generation.
% One useful method for such generation is to use MATLAB's
% publish-to-HTML function, and then "Save as PDF" from the
% Chrome browser.
%
% *Bugs:* This program will always require more documentation.
% For some models and parameters values, optimization (search)
% time may become long when starting values for optimization are far
% off. There is no sanity check of input data or parameter
% values. Array bounds are not checked. Some problems are inherited from
% MATLAB: It is not always possible to interrupt an ongoing computation.
% The program may crash on the first run after installation.
%
% (c) 2020 Martin Nilsson, RISE

%%% Units
% Unless otherwise noted, we use a consistent system of "neuronal" units 
% *ms/kHz/mV/pA/pF/GOhm/nS*. We make membrane potentials
% dimensionless by expressing them in units of noise standard deviations.

%%% New in version 7
% Previously, the main time constant tau was thought of as the RC
% membrane time constant. This lead to inconsistencies with experimental
% data. Rethinking the model showed that necessarily tau=1/mu.
% Consequently all places where mu are used in calculation (domega() and
% pdfhelper_variable()), 1/tau is used for mu.

%%% Wish list
% * Show output log in a separate, scrollable text window.
% * Fine-tune optimization and ODE solvers.
% * Implement fixed-step ODE solver in C/MEX.
% * Find "good" initial parameter approximations automatically using,
%   e.g., the metod of moments.
% * Improve style, variable and function naming, formatting, commenting,
%   markup, error reporting, etc.
% * Convert documentation markup to Doxygen.
% * XML output.
% * Rewrite everything from the beginning.

%% Initialization
% This section contains initialization and startup code
% required by the MATLAB GUI.
% Last Modified by GUIDE v2.5 20-Aug-2020 20:02:46

%%
% Required by MATLAB.
function varargout = instant(varargin)
% INSTANT Startup and initialize
    % Begin initialization code - DO NOT EDIT
    gui_Singleton = 1;
    gui_State = struct('gui_Name',       mfilename, ...
        'gui_Singleton',  gui_Singleton, ...
        'gui_OpeningFcn', @instant_OpeningFcn, ...
        'gui_OutputFcn',  @instant_OutputFcn, ...
        'gui_LayoutFcn',  [] , ...
        'gui_Callback',   []);
    if nargin && ischar(varargin{1})
        gui_State.gui_Callback = str2func(varargin{1});
    end
    if nargout
        [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
    else
        gui_mainfcn(gui_State, varargin{:});
    end
    % End initialization code - DO NOT EDIT
end

function varargout = instant_OutputFcn(~, ~, handles)
% INSTANT_OUTPUTFCN return output to the command line
% varargout  cell array for returning output args (see VARARGOUT);
% handles    structure with handles and user data (see GUIDATA)
    % Get default command line output from handles structure
    varargout{1} = handles.output;
end

%%
% INSTANT's own initialization.
function instant_OpeningFcn(hObject, ~, h, varargin)
% This function has no output args, see OutputFcn.
% It executes just before instant is made visible.
% hObject    handle to figure
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to instant (see VARARGIN)
    % Declare and choose integrator
    global multicore busycount;
    % Default logfile name
    h.logfile = fullfile(cd,'instant.log');
    % Multicore off by default
    multicore = false;
    % default values
    h.par.param = C.ParamDefaults;
    h.par.param(C.Model) = C.SmoothTruncExp;
    h.par.param(C.Mu_locked) = 0;
    h.par.param(C.Integrator) = C.AutoInt;
    h.par.param(C.Bins) = 100;
    % reset "LED" indicator
    busycount = 0;
    % Choose default command line output for instant
    h.output = hObject;
    % Mask for locked paramaters
    h.par.locked = false(1,C.NoParams);
    % Set hold on option for axes
    hold(h.axes1,'on');
    hold(h.axes2,'on');
    hold(h.axes4,'on');
    hold(h.axes5,'on');
    hold(h.axes7,'on');
    title(h.axes7,'Segment Mean (Stationarity test)');
    hold(h.axes8,'on');
    title(h.axes8,'Conditional Mean (Correlation test)');
    % Default show PDF
    h.diagtype = C.PDFDiag;
    h.par.ub = 100;
    h.ccdf = [];
    h.pdf = [];
    h.green = imread('greenled.jpg');
    h.red = imread('redled2.jpg');
    h.yellow = imread('yellowled.jpg');
    axes(h.axes4);
    axis(h.axes4,'off');
    image(h.green);
    axes(h.axes5);
    axis(h.axes5,'off');
    image(imread('logoThe.jpg'));
    axes(h.axes6);
    set(h.axes6,'Visible','off');
    h.errors = [h.edit18,h.edit19,h.edit20,...
        h.edit21,h.edit22,h.edit23];
    h.edits = [h.edit4,h.edit5,h.edit6,h.edit7,h.edit8,h.edit9];
    h.lock = [h.checkbox1,h.checkbox2,...
        h.checkbox3,h.checkbox4,h.checkbox5,h.checkbox6];
    h.sliders = [h.slider1,h.slider2,h.slider3,...
        h.slider4,h.slider5,h.slider6];
    set(h.popupmenu2,'Value',h.par.param(C.Model));
    lbs = C.ParameterBounds(1,:);
    ubs = C.ParameterBounds(2,:);
    for k = 1:C.NoParams
        set(h.sliders(k),'Min',lbs(k));
        set(h.sliders(k),'Max',ubs(k));
    end
    h = change_model(h);
    % original connected directory
    h.path = cd;
    % print cd for debugging purposes (not in log file)
    fprintf(1,'INSTANT v%.1f, current directory is:\n%s\n',C.Version,cd);
    set(h.text12,'String',...
        strcat(get(h.text12,'String'),sprintf('%.1f',C.Version)));
    set(h.text13,'String',...
        strcat(get(h.text13,'String'),sprintf(' %s',C.Date)));
    % The following is a workaround of bugs in GUIDE:
    set(h.figure1,'Name','INSTANT');
    set(h.uipanel10,'SelectionChangeFcn',...
        @(hObject,eventdata)instant('uipanel10_SelectionChangeFcn',...
            get(hObject,'SelectedObject'),eventdata,...
            guidata(get(hObject,'SelectedObject'))));
    set(h.uipanel12,'SelectionChangeFcn',...
        @(hObject,eventdata)instant('uipanel12_SelectionChangeFcn',...
            get(hObject,'SelectedObject'),eventdata,...
            guidata(get(hObject,'SelectedObject'))));
    % Initialize subgraphs
    h.queue = [C.ThresholdDist C.CondMean C.SegmentMean];
    % Update handles structure
    guidata(hObject, h);
end

%% Estimating parameters by optimization
%

%%
% Called when estimate parameter button pushed.
function pushbutton1_Callback(hObject, ~, h)
    if (~data_available(h))
        return;
    elseif (h.diagtype == C.LinearityDiag)
        h.diagtype = C.PDFDiag;
        set(h.uipanel10,'SelectedObject',h.radiobutton9);
    end
    n = str2double(get(h.edit10,'String'));
    busy(true);
    h = clear_rmse(h);
    h = optimize(h,n);
    busy(false);
    beep;
    h = recompute1(h);
    guidata(hObject, h);
end

%%
% Top level optimization.
function h = optimize(h,n)
    global multicore;
    persistent sobolcount;
    % Obtain variable bounds
    lbs = C.ParameterBounds(1,:);
    ubs = C.ParameterBounds(2,:);
    % Extract diagtype for optimizer in loop
    diagtype = h.diagtype;
    % do NOT include intervals with deviating conditional mean
    % i.e., having potential correlations (Johnson's criterion)
    cm_mask = h.cm_mask;
    t2masked = plotpoints(h.par);
    t2masked = t2masked(cm_mask);
    pdfmasked = h.pdf(cm_mask);
    cdfmasked = h.ccdf(cm_mask);
    % Extract useful data
    % (important for parfor)
    h_inf = h.h_inf;
    if (n <= 1)
        % Single optimization
        [~,h.par.param] = ...
            optimize1(h.par,h.diagtype,h.par.param(1:C.NoParams),...
                pdfmasked,cdfmasked,lbs,ubs,h_inf,t2masked);
        [~,~,h.oneminusr2,h.ksdist] = ...
            compute_model1(h.par,h.pdf,h.ccdf,h_inf);
        output_log(h,'Optimize',[],[],[],1);
        return;
    end
    % Extract model variables
    par = h.par;
    fvars = free_vars(par);
    % Remember best value
    bestfcnval = inf;
    myfprintfopen(h,...
        '\nEstimating parameters by search for global minimum:\n');
    % Temporarily set fixed step mode if auto
    if (par.param(C.Integrator) == C.AutoInt)
        par.param(C.Integrator) = C.Ode4Int;
    end
    % Copy parameter values
    thelog = repmat(par.param(1:C.NoParams),n,1);
    success = Inf(n,1);
    % Randomize free parameters
    % Initialize Sobol sequence
    if (~exist('sobolcount','var') || isempty(sobolcount))
        sobolcount = 100;
    end;
    % use sobolcount to make sure it is a new sequence
    sobolseq = scramble(sobolset(sum(fvars),...
        'Skip',1e3,'Leap',sobolcount),'MatousekAffineOwen');
    % Generate n-1 points
    rnd = net(sobolseq,n-1);
    % record that we consumed n-1 points
    sobolcount = sobolcount + n - 1;
    % Load random params into thelog
    % keep first entry for current param
    % Scale by ub/lb
    varlist = find(fvars);
    for pos = 1:sum(fvars)
        var = varlist(pos);
        thelog(2:end,var) = lbs(var) + rnd(:,pos)*(ubs(var)-lbs(var));
    end
    if (multicore)
        try
            matlabpool('open');
        catch % in case we forgot to close the pool
            matlabpool('close');
            matlabpool('open');
        end
    end
    done = 0;
    while (done < n)
        % find range to do
        if (multicore) % parallel
            % max chunksize times per loop
            kmax = min(n,done+C.Chunksize);
        else % if not parallel
            % only once per loop
            kmax = done+1;
        end
        % remember: no globals/io inside parfor!
        parfor k = (1+done) : kmax
            % First test current params
            % Protect from bad parameters
            try
                % h.pdf and h.ccdf from compute_histogram;
                % fcnval depends on h.diagtype
                [success(k), params] = ...
                    optimize1(par,diagtype,thelog(k,:),...
                        pdfmasked,cdfmasked,lbs,ubs,h_inf,t2masked);
                thelog(k,:) = params(1:C.NoParams);
            catch
                success(k) = inf;
            end
        end
        % Update visible counter
        set(h.edit10,'String',n - kmax);
        drawnow;
        % Find best new result
        [newbest, bestlist] = min(success((1+done):kmax));
        if (newbest < bestfcnval)
            bestfcnval = newbest;
            % Save if best so far
            bestindex = bestlist(1) + done;
            myfprintfopen(h,'Best so far: %12.10f for ', newbest);
            myfprintfopen(h,'parameters %f %f %f %f %f %f\n',...
                thelog(bestindex,1:C.NoParams));
            % NB: the values for fixed and variable modes differ slightly
            h.par.param(1:C.NoParams) = thelog(bestindex,1:C.NoParams);
            h = compute_model(h);
            h = redraw(h);
        end
        done = kmax;
    end
    % Extract all reasonably good solutions
    thelog = sortrows([success thelog]);
    m = sum(success < 3*bestfcnval);
    % Print the results
    myfprintfopen(h,'\n');
    for k = 1:m
        myfprintfopen(h,'%12.10f for ',thelog(k,1));
        myfprintfopen(h,'parameters: %f %f %f %f %f %f\n',thelog(k,2:end));
    end
    if (multicore)
        matlabpool('close');            
    end
    % Save the best overall
    set(h.edit10,'String',1);
    drawnow;
    output_log(h,'Optimize',[],[],[],n);
end

%%
% Single optimization.
function [fcnval, par1to6] = optimize1(par,diagtype,par1to6,...
        pdfmasked,ccdfmasked,lbs,ubs,h_inf,t2masked)
    % We assume that ISIs which do not satisfy Johnson's
    % independence criterion has been masked out
    % This function should not do I/O etc
    % for purpose of parallel exec
    fvars = free_vars(par);
    par.param(1:C.NoParams) = par1to6;
    if (par.param(C.Integrator) ~= 1) % variable or auto step mode
        options = optimset('FunValCheck','on',...
            'MaxIter',800,...
            'TolFun',1e-9,...
            'TolX',1e-9,...
            'Display','off'); % Change to 'iter' when debugging
    else % fixed step mode
        options = optimset('FunValCheck','on',...
            'MaxIter',400,...
            'TolFun',1e-6,...
            'TolX',1e-6,...
            'Display','off'); % Change to 'iter' when debugging
    end                       % otherwise 'off'
    if (diagtype ~= C.CDFDiag) % For PDF (and linearity)
        [par.param(fvars),fcnval] = lsqcurvefit(...
            @(p,t)survpdf(p,t,par.param,fvars,h_inf),... % fun
            par.param(fvars),...    % x0
            t2masked,...            % xdata
            pdfmasked,...           % ydata
            lbs(fvars),...          % lb
            ubs(fvars),...          % ub
            options);               % options
        fcnval = fcnval/sum((pdfmasked - mean(pdfmasked)).^2);
    % Case CDF
    elseif (diagtype == C.CDFDiag) % CDF/min with KSdist
        if (par.param(C.Integrator) == C.AutoInt) % use ode23 in auto mode
            par.param(C.Integrator) = C.Ode23Int; % with KSdist
        end
        options = optimoptions(@fmincon,...
            'Algorithm','active-set',...
            'Display',options.Display,...
            'FunValCheck',options.FunValCheck,...
            'MaxIter',options.MaxIter,...
            'TolFun',options.TolFun,...
            'TolX',options.TolX);
        problem.solver = 'fmincon';
        problem.objective = @(p)ksdistcdf(ccdfmasked, p, t2masked,...
            par.param, fvars, h_inf);
        problem.x0 = par.param(fvars);
        problem.Aineq = [];
        problem.bineq = [];
        problem.Aeq = [];
        problem.beq = [];
        problem.lb = lbs(fvars);
        problem.ub = ubs(fvars);
        problem.nonlcon = [];
        problem.options = options;
        [par.param(fvars),fcnval] = fmincon(problem);
    end % (fun,x0,A,b,Aeq,beq,lb,ub,nonlcon,options)
    % Make sure proper value of mu is set if unlocked
    if (~par.param(C.Mu_locked)) % Unlocked
        par.param(C.Log10mu) =...
            log10(h_inf/nuappr(1,par.param(C.Sigma_inf)));
    end
    par1to6 = par.param;
end

%% Estimating errors by bootstrapping
% Bootstrap will resample from ISI and estimate parameters using
% optimization with the current parameter values as
% starting approximation.

%%
% Called when estimate errors button pushed.
function pushbutton4_Callback(hObject, ~, h)
    if (~data_available(h))
        return;
    elseif (h.diagtype == C.LinearityDiag) % If linearity mode, set to pdf
        h.diagtype = C.PDFDiag;
        set(h.uipanel10,'SelectedObject',h.radiobutton9);
    end
    n = str2double(get(h.edit10,'String'));
    busy(true);
    h = clear_rmse(h);
    h = bootstrap(h,n);
    busy(false);
    beep;
    h = recompute1(h);
    guidata(hObject, h);
end

%%
% Estimate MSE by bootstrapping
function h = bootstrap(h,iterations)
    global multicore;
    myfprintfopen(h,'\nEstimating errors:');
    % Extract variable bounds from sliders max/min
    lbs = C.ParameterBounds(1,:);
    ubs = C.ParameterBounds(2,:);
    % Extract diagtype for optimizer in loop
    diagtype = h.diagtype;
    % Extract parameters to be perturbed
    par = h.par;
    % Work on temporary copy
    isi = h.isi;
    n = length(isi);
    % Make sure n is at least 2
    iterations = max(iterations,2);
    set(h.text30,'String',sprintf('RMSE@n=%d',iterations));
    h.par.iterations = iterations;
    done = 0;
    % Compute CRLB and unlocked model vars
    [h.crlb, mvars, cond] = compute_crlb(h);
    m = sum(mvars);
    % exclude dependent (correlated) intervals
    cm_mask = h.cm_mask;
    % Preallocate arrays
    success = false(1,iterations);
    loovar = zeros(m,n);
    loocount = zeros(1,n);
    leave_one_out = zeros(1,m);
    bootstr_bias = zeros(1,m);
    bootstr_variance = zeros(1,m);
    if (multicore)
        try
            matlabpool('open');
        catch % in case we forgot to close the pool
            matlabpool('close');
            matlabpool('open');
        end
    end
    while (done < iterations)
        % find range to do
        if (multicore) % parallel
            % max chunksize times per loop
            bmax = min(iterations,done+C.Chunksize);
        else % if not parallel
            % only once per loop
            bmax = done+1; 
        end
        parfor b = (1+done):bmax
            % generate resample index
            indx = randi(n,1,n);
            % do the major work
            [newparams, success(b), mask, varterm] = ...
                parallel_bootstrap(par,diagtype,mvars,...
                    isi,indx,lbs,ubs,cm_mask);
            if (success(b))
                % save means, i.e., sums of params
                bootstr_bias = bootstr_bias + newparams;
                % save variances, i.e., sums od squares
                bootstr_variance = bootstr_variance + ...
                    (par.param(mvars) - newparams).^2;
                % count leave-out-one samples
                loocount = loocount + (~mask);
                % collect leave-out-one variances
                loovar = loovar + varterm;
            end
        end
        % Update visible counter
        set(h.edit10,'String',iterations-bmax);
        drawnow;
        % Compress results
        total = done + sum(success);
        success(1+done:bmax) = false; % all will be false
        done = total;
    end
    if (multicore)
        matlabpool('close');
    end
    bootstr_bias = bootstr_bias/iterations - par.param(mvars);
    bootstr_variance = bootstr_variance/iterations;
    % compute final sum for leave-one-out
    mask = (loocount > 0);
    for i=1:m
        loovar(i,mask) = loovar(i,mask)./loocount(mask);
        leave_one_out(i) = sum(loovar(i,:))/sum(mask);
    end
    set(h.edit10,'String',1);
    drawnow;
    % Estimate variance by the ".632" bootstrapping rule
    h = output_log(h,'Bootstrap',bootstr_bias,...
        exp(-1) * bootstr_variance + (1-exp(-1)) * leave_one_out,...
        cond, iterations);

end

%%
% Perform the core of the bootstrapping loop in parallel.
function [newparams, success, mask, varterm] = ...
        parallel_bootstrap(par,diagtype,mvars,isi,indx,lbs,ubs,cm_mask)
    try % protect from bad parameters
        % compute histogram data for new spike train
        isi = isi(indx);
        [~,~,pdf,ccdf,~,h_inf,~] = compute_hist1(par,isi,cm_mask);
        % estimate params for new spike train
        t2 = plotpoints(par);
        [~,params] = optimize1(par,diagtype,par.param(1:C.NoParams),...
            pdf(cm_mask),ccdf(cm_mask),lbs,ubs,h_inf,t2(cm_mask));
        % record estimates
        newparams = params(mvars);
        % translate index to bit mask
        n = length(isi);
        mask = false(1,n);
        mask(indx) = 1;
        % collect leave-out-one variances
        m = sum(mvars);
        varterm = zeros(m,n);
        mvar = find(mvars);
        for i=1:m
            varterm(i,~mask) = (par.param(mvar(i)) - params(mvar(i)))^2;
        end
        success = true;
    catch
        newparams = [];
        mask = [];
        varterm = [];
        success = false;
    end
end

%% I/O
%

%%
% Top level function for loading data.
function h = reload_data(h)
    h = clear_rmse(h);
    [h, the_data] = load_data_from_file(h);
    h = parse_data(h, the_data);
end

%%
% Load .txt (data) and .mat (parameter) files.
function [h, the_data] = load_data_from_file(h)
    % Load .txt data file
    if (isfield(h.par,'file') == 0)
        myfprintfopen(h,'\nNo data file given%s\n');
        return;
    end
    % Load parameters first, if .mat or .bak
    [~, ~, ext] = fileparts(h.par.file);
    if (strcmp(ext,'.mat') || strcmp(ext,'.bak'))
        h = reload_params(h);
    end
    try
        the_data = importdata(fullfile(h.path,h.par.file));
    catch % Error when loading file
        warning();
        myfprintfopen(h,'\nError when trying to importdata file %s\n',...
            fullfile(h.path,h.par.file));
        beep;
        return;
    end
    myfprintfopen(h,'\n%s --- Loaded spike train from %s\n',...
        datestr(now),fullfile(h.path,h.par.file));
    % Extract data part if available from reload_params
    if (isstruct(the_data) && ...
        isfield(the_data,'data'))
        the_data = the_data.data;
    elseif (isstruct(the_data))
        warning();
        myfprintfopen(h,'\nData file %s has the wrong format\n',...
            fullfile(h.path,h.par.file));
        beep;
        return;
    end
    if (~isnumeric(the_data))
        warning();
        myfprintfopen(h,'\nData file %s has the wrong format\n',...
            fullfile(h.path,h.par.file));
        beep;
        return;
    end
end

%%
% Load a spike train.
function h = loadspiketrain(h,file)
    h.par.file = file;
    set(h.text11,'String',file);
    h = reload_data(h);
    h = compute_histogram(h);
    h = compute_model(h);
    h = redraw(h);
end

%%
% Load file of parameter data.
function h = loadfile(fname)
    h = [];
    % strip comments and blanks
    if (isempty(fname) || fname(1) == '%' || ...
            fname(1) == '#' || fname(1) == ';')
        return;
    end
    fname = strtok(fname,'%#;');
    if (isempty(fname))
        return;
    end
    h = guidata(gcbo);
    h = loadspiketrain(h,fname);
    if (~data_available(h))
        h = [];
        return;
    end
end

%%
% Save back a modified parameter file to disk.
function saveback(h,path,fname)
    [~, name, ext] = fileparts(fname);
    try
        % first save new file as .tmp
        save_it(fullfile(path,[name '.tmp']),h);
        % save old file as backup
        movefile(fullfile(path,[name ext]),fullfile(path,[name '.bak']));
        % finally move new file to original file name
        movefile(fullfile(path,[name '.tmp']), fullfile(path,[name ext]));
    catch
        warning();
        myfprintfopen(h,...
          '\napply_to_batch: Error when trying to save back file %s\n',...
            fullfile(path,fname));
        beep;
    end
end

%%
% Single point where parameter files are save.
function save_it(pathfile,h)
    h.par.version = C.Version; % Unique save point!
    save(pathfile,'-struct','h','par');
end

% Log output from optimize and bootstrap procedures.
function h = output_log(h,cmd,bias,variance,cond,n)
    fid = fopen(h.logfile,'a');
    % Output to screen and logfile
    h = output_log1(fid,h,cmd,bias,variance,cond,n);
    % Output to logfile
    if (fid ~= -1) % if file opened ok
        fclose(fid);
    end
end

%%
% Print a matrix on the log file.
function myprintmatrix(fid,m)
    for i=1:size(m,1)
        for j=1:size(m,2)
            myfprintf(fid,'%#-12.4g',m(i,j));
        end
        myfprintf(fid,'\n');
    end
end

%%
% Print output from parameter and error estimates on the logfile.
function h = output_log1(fid,h,cmd,bias,variance,cond,n)
    if (strcmp(cmd,'Bootstrap')) % unlocked vars for bootstrap
        mvars = unlocked_model_vars(h.par);
    else % all model vars (not just free vars) for optimize
        mvars = model_vars(h.par);
    end
    myfprintf(fid,'\nParameter estimates using model %s:\n',...
                    cell2mat(C.ModelName(h.par.param(C.Model))));
    arrayfun(@(x)myfprintf(fid,'%s',x),cell2mat(C.ParamName(mvars)));
    myfprintf(fid,'\n');
    arrayfun(@(x)myfprintf(fid,'%#-12f',x),h.par.param(mvars));
    myfprintf(fid,'\n1-R^2 = %.8f  KSdist = %.8f\n',...
        h.oneminusr2,h.ksdist);
    if (strcmp(cmd,'Bootstrap'))
        myfprintf(fid,...
          'Bias estimates based on bootstrap with %d resamplings:\n',n);
        arrayfun(@(x)myfprintf(fid,'%-12f',x),abs(bias));
        myfprintf(fid,...
          '\nSD estimates based on bootstrap with %d resamplings:\n',n);
        arrayfun(@(x)myfprintf(fid,'%-12f',x),sqrt(variance));
        myfprintf(fid,...
          '\nRMSE estimates based on bootstrap with %d resamplings:\n',n);
        rmse = sqrt((bias).^2+variance); % a very important formula!
        arrayfun(@(x)myfprintf(fid,'%-12f',x),rmse);
        h.par.rmse = zeros(1,C.NoParams);
        h.par.rmse(mvars) = rmse;
        h = display_rmse(h);
        myfprintf(fid,'\nCramer-Rao Lower Bounds on SD');
        myfprintf(fid,' (Fisher info cond: %.1e)\n',cond);
        arrayfun(@(x)myfprintf(fid,'%-12f',x),h.crlb);
        myfprintf(fid,'\n');
    end
end

%%
% Print an item both in the logfile and on the MATLAB console.
function myfprintf(fid,varargin)
    fprintf(1,varargin{:}); 
    if (fid ~= -1)
        fprintf(fid,varargin{:}); 
    end
end
    
%%
% Append a printout to the logfile.
function myfprintfopen(h,varargin)
    fid = fopen(h.logfile,'a');
    myfprintf(fid,varargin{:});
    if (fid ~= -1)
        fclose(fid);
    end
end

%%
% Load .mat parameter file.
function h = reload_params(h)
    try
        p = load(fullfile(h.path,h.par.file),'-mat');
        h.origfile = h.par.file;
    catch % Error when loading file
        warning();
        myfprintfopen(h,...
            '\nError when trying to load parameter file %s\n',...
            fullfile(h.path,h.par.file));
        beep;
        return;
    end
    myfprintfopen(h,'\n%s --- Loaded parameters from %s\n',...
        datestr(now),fullfile(h.path,h.par.file));
    if (~isfield(p.par,'version') || p.par.version < C.Version - 0.001)
        % Update parameters from old version to current
        q = p.par.param;
        % here we can adapt parameters if different in a previous version
        % p.par.param(C.W) = 10^q(C.Log10tau)*log(10^q(C.Log10sigma_0));
        p.par.version = C.Version;
    end
    step = h.par.param(C.Integrator); % Save fixed/variable step indicator
    h.par = p.par;
    h.par.param(C.Integrator) = step; % restore possibly clobbered step
    if (~isfield(h,'diagtype'))
        h.diagtype = C.PDFDiag;
    end
    % Set locks
    % mu needs to be taken care of explicitly
    if (~isfield(h.par,'locked'))
        h.par.locked = false(1,C.NoParams);
    end
    h.par.param(C.Mu_locked) = h.par.locked(C.Log10mu);
    set(h.lock(h.par.locked),'Value',1);
    set(h.lock(~h.par.locked),'Value',0);
    % Set filename
    set(h.text11,'String',...
        strcat(h.origfile,' (',h.par.file,')')); % filename
    % Change model
    h = change_model(h);
end

%%
% Check if file was loaded OK.
function ok = fileok(file)
    ok = (~isequal(file,0));
end

%%
% Load a file and generate a screen shot.
function load_and_gendoc1(fname)
    % load the file
    h = loadfile(fname);
    if (isempty(h))
        return;
    end
    gendoc1(h,fname);
end

%%
% Generate a PNG screen shot and save it to file.
function gendoc1(h,fname)
    % It is difficult to generate nice graphics from MATLAB.
    % PNG seems to works OK, but controls are fuzzy.
    % PDF does not work well from MATLAB 2013a. It loses
    % parts of a figure. Also, it does not work in deployed code.
    % Using HG2 breaks GUIDE in R2013a.
    % For EPS ('-depsc') fonts are missing.
    hfig = h.figure1;
    set(hfig,'PaperUnits','centimeters');
    set(hfig,'Units','centimeters');
    pos = get(hfig,'Position');
    set(hfig,'PaperSize', [pos(3) pos(4)]);
    set(hfig,'PaperPositionMode', 'manual');
    set(hfig,'PaperPosition',[0 0 pos(3) pos(4)]);
    set(hfig,'PaperType','A4');
    [~, name, ext] = fileparts(fname);
    print(hfig,'-dpng','-r600',fullfile(h.path,strcat(name,'.png')));
    guidata(gcbo,h);
end

%% Graphics
%

%%
% Grid points for curve plotting.
function t2 = plotpoints(par)
% We use a step that is half the bandwidth.
    % Same as par.lb : bw/2 : par.ub
    % but for safely avoiding round-off errors
    bins = par.param(C.Bins);
    t2 = (0:2*bins)/bins*par.ub/2;
end

%%
% Redraw graphics.
function h = redraw(h)
    % draw supplementary diagrams first
    % to have something to look at while we are waiting
    h = redraw_suppl(get(h.uipanel12,'SelectedObject'),h);
    drawnow;
    % now draw the main diagram
    ax1 = h.axes1;
    cla(ax1);
    t2 = plotpoints(h.par);
    if (h.diagtype == C.PDFDiag) % Display PDF
        set(h.text31,'Visible','off');
        set(h.text32,'Visible','on');
        if (data_available(h)) % ISI data available
            t1 = h.t1;
            histo = h.histo;
            bar(ax1,t1, histo,...
                'FaceColor',C.HistoFaceColor,...
                'EdgeColor',C.HistoEdgeColor);
            cm_mask = h.cm_mask(2:2:length(h.cm_mask)-1);
            cm_mask = cm_mask & ...
                h.cm_mask(1:2:length(h.cm_mask)-2) & ...
                h.cm_mask(3:2:length(h.cm_mask));
            histo(cm_mask) = 0;
            bar(ax1,t1, histo,...
                'FaceColor',C.HistoFaceColorDepend,...
                'EdgeColor',C.HistoEdgeColorDepend);
        end
        % Plot model
        plot(ax1,t2,h.model_pdf,'Color','r','LineWidth',C.LineWidth);
        if (data_available(h)) % Plot KDE dashed, on top
            plot(ax1,t2,h.pdf,'--k','LineWidth',C.LineWidth);
            legend(ax1,'ISI histogram','Contains correlated ISIs',...
                'Parametric model','Kernel Density Estimator');
        else % No ISI data yet
            legend(ax1,'Model'); 
        end
    elseif(h.diagtype == C.CDFDiag) % Display CDF
        set(h.text31,'Visible','off');
        set(h.text32,'Visible','on');
        plot(ax1,t2,1 - h.model_ccdf,...
                 'Color','r','LineWidth',C.LineWidth);
        if (data_available(h))
            plot(ax1,t2,1 - h.ccdf,...
                     '--k','LineWidth',C.LineWidth);
            legend(ax1,'ISI CDF','Model');
        else
            legend(ax1,'Model');
        end
    else % Display Linearity (V-f transfer)
        busy(true);
        set(h.text31,'Visible','on');
        set(h.text32,'Visible','off');
        [h.inl,h.dnl,h.sigma,h.f,smin,smax] =...
            vfgain(h.par.outliers,h.par.param);
        busy(false);
        beep;
        plot(ax1,-h.sigma,h.f,'-r','LineWidth',C.LineWidth);
        % Append linearity data to logfile
        % myfprintfopen(h,'%f ', 10^h.par.param(C.Log10tau))
        % myfprintfopen(h,', %f',h.f)
        % myfprintfopen(h,'\n')
        % make sure y axis includes 0
        plot(ax1,[-2],[0],'-k');
        x = h.par.param(C.Sigma_inf);
        y = 1000/meanisi(h.par.outliers,x,h.par.param);
        plot(ax1,[-x],[y],'-ko','MarkerSize',6,'MarkerFaceColor','k');
        axes(ax1);
        msg1 = sprintf('Non-linearity for %1.0g < ', round(-h.sigma(smax)));
        msg2 = sprintf(' < %g:', -h.sigma(smin));
        text(0.6,0.30,[msg1,'{-\it\sigma}_\infty{}',msg2],...
            'Fontsize',8,'Units','normalized');
        msg = sprintf('INL = %.4f',h.inl);
        text(0.6,0.24,msg,'Fontsize',8,'Units','normalized');
        msg = sprintf('DNL = %.4f',h.dnl);
        text(0.6,0.18,msg,'Fontsize',8,'Units','normalized');
        legend(ax1,...
          'Frequency transfer function {\it{}f} ({-\it\sigma}_\infty)',...
          'Location', 'NorthWest');
    end
    drawnow;
end

%%
% Draw supplementary figures and setup axes.
function h = redraw_suppl(~, h)
    if (data_available(h) && get(h.checkbox8,'Value') == 0)
        title(h.axes7,C.SubgraphTitle{h.queue(3)});
        h = draw_subgraph(h.axes7,h,h.queue(3));
        title(h.axes8,C.SubgraphTitle{h.queue(2)});
        h = draw_subgraph(h.axes8,h,h.queue(2));
    end
    ax = h.axes2;
    if (h.queue(1) == C.CondHistogram)
        cla(h.axes2);
        ax = h.axes6;
    else
        h = myrmfield(h,'surf');
        cla(h.axes6);
    end
    cla(ax);
    ylim(ax,'auto');
    h = draw_subgraph(ax,h,h.queue(1));
    switch (h.queue(1))
        case C.MembranePot
            h.legend = ...
                legend(ax,...
    'Membrane Potential {\it V}_m({\it{}t})  [unit: noise SD]',...
                     'Threshold','Location','Southeast');
            h = suppl_visibility(h,'on','on','off','off','on');
        case C.ThresholdDist
            h.legend = ...
                legend(ax,...
    'Threshold distance {\it\sigma} ({\it{}t})  [unit: noise SD]',...
                     'Threshold','Location','Northeast');
            h = suppl_visibility(h,'on','on','off','off','on');
        case C.SegmentMean
            h = suppl_visibility(h,'on','off','off','off','off');
        case C.CondMean
            h = suppl_visibility(h,'on','off','off','off','on');
        case C.CondHistogram
            h = suppl_visibility(h,'off','off','on','on','on');
        case C.Autocorrel
            h = suppl_visibility(h,'on','off','off','off','off');
        case C.MuEst
            h.legend = legend(ax,'Estimates of \it\mu\rm from tail',...
                'Selected estimate','Location','Southwest');
            h = suppl_visibility(h,'on','on','off','off','on');
    end
end

%%
% Draw the actual supplementary figures.
function h = draw_subgraph(ax,h,subgraph)
    cla(ax);
    ylim(ax,'auto');
    switch (subgraph)
        case C.MembranePot
            t2 = plotpoints(h.par);
            y2 = sigma(t2,h.par.param);
            if (size(y2,2) < size(t2,2))
                y2 = cat(2,y2,y2(1)*ones(1,size(t2,2)-size(y2,2)));
            end
            mask = true(1,length(t2));
            model = h.par.param(C.Model);
            if (model == C.Exp)
                mask = (y2 < 8.5);
            elseif (model == C.TruncExp || model == C.SmoothTruncExp ||...
                    model == C.VarSmoothTruncExp)
                mask = (y2 < 0.95*h.par.param(C.Sigma_max));
            end
            plot(ax,t2(mask),-y2(mask),'-r',[t2(1),t2(end)],...
                [0,0],'--b','LineWidth',C.LineWidth);
       case C.ThresholdDist
            t2 = plotpoints(h.par);
            y2 = sigma(t2,h.par.param);
            if (size(y2,2) < size(t2,2))
                y2 = cat(2,y2,y2(1)*ones(1,size(t2,2)-size(y2,2)));
            end
            plot(ax,t2,y2,'-r',[t2(1),t2(end)],...
                [0,0],'--b','LineWidth',C.LineWidth);
        case C.CondHistogram
            z = cond_hist(h.isi, h.index, h.par.ub, 11);
            l = h.par.ub;
            h.surf = surf(ax,0:l/10:l,0:l/10:l,z,'MeshStyle','row');
            hObj2 = rotate3d;
            set(hObj2,'RotateStyle','box','Enable','on');
        case C.SegmentMean
            sm = h.segmentmeans;
            M = h.totalmean;
            nlist = 1:length(sm);
            d = h.twosd;
            cla(ax);
            plot(ax,nlist,sm,'r','LineWidth',C.ThinLineWidth);
            plot(ax,[1,length(sm)],[M + d,M + d],'--b',...
                'LineWidth',C.ThinLineWidth);
            plot(ax,[1,length(sm)],[M - d,M - d],'--b',...
                'LineWidth',C.ThinLineWidth);
        case C.CondMean
            n = 2*h.par.param(C.Bins);
            [cm, H, m, v] = cond_mean(h.isi,h.index,h.par.ub,n+1);
            tl = (0:n)*h.par.ub/n;
            cla(ax);
            plot(ax,tl,cm,'r','LineWidth',C.ThinLineWidth);
            plot(ax,tl,m + 2*sqrt(v./H),'--b','LineWidth',C.ThinLineWidth);
            plot(ax,tl,m - 2*sqrt(v./H),'--b','LineWidth',C.ThinLineWidth);
        case C.Autocorrel
            m = mean(h.isi);
            plot(ax,-length(h.isi)+1:length(h.isi)-1,autocorr(h.isi - m));
        case C.MuEst
            t2 = plotpoints(h.par);
            muappr = h.etail/nuappr(1,h.par.param(C.Sigma_inf));
            estmu = h.h_inf/nuappr(1,h.par.param(C.Sigma_inf));
            if (isfield(h,'etail'))
                ylim(ax,[0 2*estmu]);
                plot(ax,t2(h.cm_mask),muappr,'.k',...
                    [t2(1),t2(end)],[estmu,estmu],'--r',...
                    'LineWidth',C.LineWidth);
            end
    end
end

%%
% Set visibility of figures.
function h = suppl_visibility(h,axes2,legend,axes6,surf,units)
    set(h.text33,'Visible',units);
    if (isfield(h,'axes2'))
        set(h.axes2,'Visible',axes2);
    end
    if (isfield(h,'legend'))
        set(h.legend,'Visible',legend);
    end
    if (isfield(h,'axes6'))
        set(h.axes6,'Visible',axes6);
    end
    if (isfield(h,'surf'))
        set(h.surf,'Visible',surf);
    end
end

%% Statistics
%

%%
% Compute initial characteristics of spike train.
function h = parse_data(h, the_data)
    % Extract first column
    s = size(the_data);
    if (s(1,2) > 1)
        the_data = the_data(:,1);
    end
    % Check default units, default to 1
    if (~isfield(h.par,'units') || h.par.units <= 0)
        h.par.units = 1;
    end
    set(h.edit11,'String',h.par.units);
    t = h.par.units * the_data';
    % Check if data was incremental or absolute
    isi = t(2:end)-t(1:end-1);
    if (abs(sum(sign(isi))) < 0.9 * length(isi))
        isi = t;
    end
    % Check if upper bound set, default to truncated mean+8*SD
    % Round up to 10ms
    if (~isfield(h.par,'ub') || h.par.ub <= 0)
        h.par.ub = 10*ceil(0.4*median(isi));
    end
    set(h.edit3,'String',h.par.ub); 
    % Check if outliers set, default to 2*upper bound
    if (~isfield(h.par,'outliers') || h.par.outliers < 0)
        h.par.outliers = 2*h.par.ub;
    end
    set(h.edit12,'String',h.par.outliers);
    % Check stationarity, default extract stationary
    if (~isfield(h.par,'xstationary'))
        h.par.xstationary = 1;
    end
    set(h.checkbox7,'Value',h.par.xstationary);
    % Remove outliers
    isi = between(0,h.par.outliers,isi);
    % Extract stationary segments
    h.index = 1:length(isi);
    if (get(h.checkbox7,'Value'))
        [isi, h.index] = stationary(isi, h.index, true);
    end
    % h.index keeps index in original sequence
    % this is needed for computing conditional mean
    [~, ~, h.segmentmeans, h.stationaryfraction,...
        h.totalmean, h.twosd] = stationary(isi, [], false);
    h.isi = isi;
    % Check if tail set, default to trunc mean
    if (~isfield(h.par,'ttail') || isnan(h.par.ttail) || h.par.ttail < 0)
        h.par.ttail = round(mean(between(0,h.par.outliers,h.isi)));
    end
    set(h.edit16,'String',h.par.ttail);
    % Compute bandwidth  
    h = recompute_bw(h);
    % intervals satisfying Johnson's independence criterion
    h.cm_mask = conditional_mean_mask(h.isi,h.index,...
        h.par.param(C.Bins),h.par.ub);
    % Finally, print results
    myfprintfopen(h,'Time unit %.2f ms, outlier when > %.2f',...
        h.par.units,h.par.outliers);
    if (h.par.xstationary)
        myfprintfopen(h,' stationary data extraction');
    end
    myfprintfopen(h,'\nFrom t = 0 to %.2f, tail starts at %.f, ',...
        h.par.ub,h.par.ttail);
    myfprintfopen(h,'%d histogram bins.\n',h.par.param(C.Bins));
    myfprintfopen(h,'ISI mean %.2f, SD %.2f, ',mean(isi),std(isi));
    myfprintfopen(h,'and length %d.\n',length(isi));
end

%%
% Iterate extracting stationary segments from spike trains.
function [isi, index, m, x, M, delta] = stationary(isi, index, extract)
    [isi, ~, ~, x, ~, ~] = extractstat(isi, [], false);
    while (x > 0.05 && extract)
        [isi, index, ~, ~, ~, ~] = extractstat(isi,index,true);
        [isi, ~, ~, x, ~, ~] = extractstat(isi,[],false);
    end
    [isi, ~, m, x, M, delta] = extractstat(isi,index,false);
end

%%
% Extract stationary segments of spike train.
function [list, newindex, m2, x, M, delta] = ...
        extractstat(isi, index, extract)
    %segs = floor(sqrt(length(isi)));
    %L = floor(length(isi)/segs);
    L = min(100,floor(sqrt(length(isi))));
    segs = floor(length(isi)/L);
    n = L * segs;
    isi = isi(1:n);
    M = mean(isi);
    sd = std(isi,1);
    delta = 2*sd/sqrt(L);
    p = 0;
    m = zeros(1,segs);
    % Do not preallocate m2!
    for i = 1:segs
        m(i) = mean(isi((i-1)*L+1:i*L));
        if (abs(m(i) - M) < delta)
            stationary(p*L+1:p*L+L) = isi((i-1)*L+1:i*L);
            if (extract)
                newindex(p*L+1:p*L+L) = index((i-1)*L+1:i*L);
            end
            p = p + 1;
            m2(p) = m(i);
        end
    end
    if (extract)
        list = stationary;
    else
        list = isi;
        newindex = index;
    end
    x = (segs - p)/segs;
end

%%
% Generate artificial spike train with current parameters.
function isi = synthetic_isi(par, n)
    % assume that parameters are available
    % needs: par.outliers, par.param, par.units
    a = 0;
    b = par.outliers;
    [ccdf, pdf] = survivor([a b],par.param);
    m = max(pdf(a:1e-4*(b-a):b));
    isi = arrayfun(@(t)generate(a,b,ccdf),1:n)/par.units;
end

%%
% Sample one interval from the parametric distribution.
function t = generate(a,b,ccdf)
    c = rand(1,1);
    c = (1-c)*ccdf(a) + c*ccdf(b);
    g = @(t)(ccdf(t)-c);
    t = fzero(@(t)(ccdf(t)-c),[a,b]);
end

%%
% *Histogram functions.*
% Top level function for computing histograms.
function h = compute_histogram(h)
    % Check if possible to compute histogram/KDE
    if (~data_available(h)) 
        return;
    end
    busy(true);
    [h.t1,h.histo,h.pdf,h.ccdf,h.etail,h.h_inf,h.entropy] = ...
        compute_hist1(h.par,h.isi,h.cm_mask);
    list = between(0,h.par.outliers,h.isi);
    set(h.text23,'String',sprintf('%.2f',mean(list)));
    set(h.text26,'String',sprintf('%.2f',std(list)));
    set(h.text24,'String',length(list));
    set(h.text28,'String',sprintf('%.2f',h.entropy));
    busy(false);
end

%%
% Low-level function for computing histogram/KDE data.
function [t1,histo,pdf,ccdf,munu,h_inf,entropy] =...
  compute_hist1(par,isi,cm_mask)
    % Check if possible to compute histogram/KDE
    % outliers are already removed; only ok intervals remain
    ub = par.ub;
    bins = par.param(C.Bins);
    bw = ub/bins;
    % t1 are the bin centers
    % we include overflow and underflow bins here
    % there should be an integer number of bins between 0 and ub
    t1 = (0 : bins + 1) * bw - bw/2;
    % histo is the histogram to be shown
    histo = hist(isi,t1); % = length(isi)
    % sum total number of cases, incl u/f and o/f
    totalcases = sum(histo);
    % Drop bottom and top (u/f and o/f) bins
    t1 = t1(2:end-1);
    histo = histo(2:end-1);
    % probability per bin
    histo = histo/totalcases/ub*bins;
    % t2 are the plot points, two per bin plus one
    t2 = plotpoints(par);
    % pdf is the KDE
    pdf = ksdensity(isi,[-bw/2 t2 ub+bw/2],...
        'kernel','epanechnikov','width',bw);
    % Drop first and last (possibly edge distorted) elements of pdf
    % pdf will be same size as t2, containing data for t=0
    pdf = pdf(2:end-1);
    % information entropy
    mask = (pdf > 0);
    entropy = sum(-log2(pdf(mask)).*pdf(mask))*bw;
    % Now compute cdf
    isi = sort(isi);
    % observing that there may be multiple ISIs of the same size
    edges = (1e-4 < abs([isi inf]-[-1 isi])); % Compare neighbours
    nlist = 1:(length(isi)+1);
    xedges = nlist(edges);
    x = (xedges(2:end)-1+xedges(1:end-1))/2;
    % Add elements to cdf for interpolation
    dt = 1e-6;
    cdf = interp1([-dt;isi(edges(1:end-1))';ub+dt],...
                  [[0 x]/length(isi) 1],...
                  t2,'linear','extrap');
    ccdf = normalize_survivor(1 - cdf);
    % Compute (E[T|T>T1] - T1) for tail, for estimation of mu
    % mu approx = 1/nu(1,sigma_inf) * 1/(E[T|T>T1] - T1);
    % Only use ISI > par.ttail for this
    % Compute E[T|T>Ttail] - Ttail as first approximation
    % h_inf = mu*nu(sigma_inf);
    % This is an importnat entity, since it is the fundamental
    % eigenvalue of the Sturm-Liouville system. It is nice that it can
    % be computed directly from the histogram data. 
    h_inf = 1/(mean(isi(isi > par.ttail)) - par.ttail);
    % Fit exponential function to tail using least squares
    options = optimoptions('lsqcurvefit','Display','off',...
        'Algorithm','Levenberg-Marquardt');
    munu = zeros(1,sum(cm_mask - 2));
    t2masked = t2(cm_mask);
    ccdfmasked = ccdf(cm_mask);
    for n = 1:length(ccdfmasked - 2)
        x = lsqcurvefit(@(x,t) x(1)*exp(-x(2)*t),...
            [1 h_inf],t2masked(n:end),ccdfmasked(n:end),[],[],options);
        munu(n) = x(2);
        % log10(mu) approx = log10(munu/nu(1,sigma_inf))
    end
    %h_inf = median(munu(t2masked > par.ttail));
    h_inf = contmax(munu(t2masked > par.ttail)); % Seems best!
end

%%
% Compute autocorrelation.
function corr = autocorr(t)
    t = t(:);
    n = size(t,1);
    corr = ifft(abs(fft(t,2^nextpow2(2*n-1))).^2);
    corr = [corr(n:-1:2); corr(1:n)]./corr(1);
end

%%
% Find which intervals satisfy Johnson's independence criterion.
function mask = conditional_mean_mask(isi,index,bins,ub)
    n = 2*bins;
    [cm, H, m, v] = cond_mean(isi,index,ub,n+1);
    mask = (abs(cm - m) <= 2*sqrt(v./H));
end

%%
% Find optimal bandwidth (binsize).
function h = recompute_bw(h)
    if (~isfield(h.par,'ub'))
        return;
    end
    % Compute bw from data if not given
    if (~isfield(h.par,'param') || ...
            isnan(h.par.param(C.Bins)) || ...
            h.par.param(C.Bins) <= 1)
        % use half the optimal estimate for normal kernels
        [~,~,bw] = ksdensity(between(0,h.par.ub,h.isi));
        h.par.param(C.Bins) = 2*h.par.ub/bw;
    end
    h.par.param(C.Bins) = round(h.par.param(C.Bins));
    set(h.edit2,'String',h.par.param(C.Bins));
end

%%
% Conditional mean.
function [cm, H, m, v] = cond_mean(isi, index, xmax, n)
% n is the number of bins AND points (middle of bins)
% starting at x = 0 and ending at x = xmax.
    h = xmax/n;
    H(n) = 0;
    cm(n) = 0;
    for j = 2:min(length(index),length(isi))-1
        if (index(j) + 1 == index(j+1))
            k = 1 + floor(isi(j)/h + 0.5); % the 0.5 is important
            if (k <= n)
                H(k) = H(k) + 1;
                cm(k) = cm(k) + isi(j + 1);
            end
        end
    end
    cm = cm./H;
    m = mean(isi);
    v = var(isi);
end

%%
% Conditional histogram
function [y] = cond_hist(isi, index, xmax, n)
    h = xmax/n;
    y(n) = 0;
    N(n) = 0;
    H(n,n) = 0;
    for j = 2:length(isi)-1
        if (index(j-1) + 1 == index(j) && index(j) == index(j+1) - 1)
            p = min(n,1 + floor(isi(j-1)/h));
            k = min(n,1 + floor(isi(j)/h));
            H(p,k) = H(p,k) + 1;
            N(p) = N(p) + 1;
        end
    end
    for p = 1:n
        y(p,:) = H(p,:)./N(p)/h;
    end
end

%%
% Cram?r-Rao lower bounds.
function [sd, mvars, fisher_cond, m] = compute_crlb(h)
    % The Fisher info matrix should be positive semidefinite
    % This can be checked by looking at the eigenvalues
    oldstep = h.par.param(C.Integrator); % save old step
    if (oldstep == C.Ode4Int)
        % always variable step by default for CRLB!
        h.par.param(C.Integrator) = C.Ode23Int;
    end
    mvars = unlocked_model_vars(h.par);
    m = fisher_information(h,sqrt(eps));
    sd = sqrt(diag(inv(m))'/length(h.isi));
    fisher_cond = cond(m);
    h.par.param(C.Integrator) = oldstep; % back to original step
end

%%
% Fisher information.
% The Fisher information matrix provides a lot of useful indications:
% * If the condition number is large, there may be a redundant parameter
% * The smallest eigenvalue points out the most redundant parameter(s)
% * Its inverse gives the CRLB, lower bounds on variance estimates
% * The largest eigenvalue shows which parameter conveys information
function matrix = fisher_information(h,dv)
    p = h.par.param;
    % Find indices of relevant vars
    vars = find(unlocked_model_vars(h.par));
    % Set mu from sigma_inf unless locked
    % From v7, mu is not included by unlocked_model_vars
    % p(C.Log10mu) = mumod(p,h.h_inf);
    p(C.Log10mu) = -p(C.Log10tau);
    % Compute central pdf
    a = 0;
    b = h.par.outliers; % Not just ub, because we need whole pdf
    [~, pdf] = survivor([a,b],p);
    matrix = zeros(length(vars));
    for i = 1:length(vars)
        v1 = vars(i);
        for j = 1:i
            v2 = vars(j);
            matrix(i,j) = fisher_element(p,v1,v2,dv,a,b,pdf);
            if (i ~= j)
                matrix(j,i) = matrix(i,j);
            end
        end
    end
end

%%
% Expectation of second partial derivatives.
function pd = fisher_element(p, v1, v2, dv, a, b, pdf)
    k = 1/(4*dv*dv);
    lnp1 = @(t)logpdf(t, p, v1, +dv, a, b);
    lnp2 = @(t)logpdf(t, p, v1, -dv, a, b);
    lnp3 = @(t)logpdf(t, p, v2, +dv, a, b);
    lnp4 = @(t)logpdf(t, p, v2, -dv, a, b);
    integrand = @(t)(lnp1(t)-lnp2(t)).*(lnp3(t)-lnp4(t)).*pdf(t)*k;
    % compute expectation:
    pd = integral(integrand,a,b);
end

function lnp = logpdf(t, p, v, dv, a, b)
    p(v) = p(v) + dv;
    [~, pdf] = survivor([a, b], p);
    lnp = -log(pdf(t));
end

%%
% Find list data between two bounds.
function c = between(lb,ub,x)
    c = x(lb <= x & x <= ub); % Logical array
end

%%
% Compute "most common" value in a set l of data.
function [maxx,maxf] = contmax(l)
    [f,xi] = ksdensity(l,'npoints',C.ContMax);
    [maxf,maxi] = max(f);
    maxx = xi(maxi);
end

%%
% Check if data is available.
function availp = data_available(handles)
    availp = (isfield(handles,'isi') && ~isempty(handles.isi));
end

%% Computing the Model
%

%%
% Top level function for computing the model.
function h = compute_model(h, varargin)
    if (~isfield(h,'h_inf'))
        h.h_inf = 10^h.par.param(C.Log10mu)*...
            nuappr(1,h.par.param(C.Sigma_inf));
    end
    if (~data_available(h))
        h.cm_mask = true(1,length(plotpoints(h.par)));
    end
    [h.model_pdf,h.model_ccdf,h.oneminusr2,h.ksdist] =...
        compute_model1(h.par,h.pdf,h.ccdf,h.h_inf);
    h = set_display_par(h);
end

%%
% Find variables used by the model
function vars = model_vars(par)
    % Mask tablep for variables used in models
    % Used for computing and printing
    persistent m;
    if (isempty(m))
        m = C.ModelVars;
    end
    vars = m(par.param(C.Model),:);
end

%%
% Generate mask for unlocked model variables.
function vars = unlocked_model_vars(par)
    vars = model_vars(par) & ... % Include variables in model
        ~par.locked; % Don't include locked vars
end

%%
% Generate mask for free variables, i.e.,
% unlocked model variables that should be optimized.
function vars = free_vars(par)
    % Variables that should be searched by optimization
    vars = model_vars(par) & ... % Include variables in model
        C.NonMuVars & ... % Don't include mu
        ~par.locked; % Don't include locked vars
end

%%
% Low-level function for computing the model.
function [model_pdf,model_ccdf,oneminusr2,ksd] = ...
        compute_model1(par,pdf,ccdf,h_inf)
    t2 = plotpoints(par);
    % Temporary settings of oneminusr2 and ksd
    oneminusr2 = 1;
    ksd = 1;
    % Set mu from sigma_inf unless locked
    % From v7, set mu from tau instead
    % par.param(C.Log10mu) = mumod(par.param,h_inf);
    par.param(C.Log10mu) = -par.param(C.Log10tau);
    try
        % Solve differential equation
        int = [0, par.ub];
        [ccdfcn,pdfcn] = survivor(int,par.param);
        % Apply functions on t2 plotpoints
        model_pdf = pdfcn(t2);
        if (any(model_pdf < 0))
            % The computed PDF being negative indicates
            % that more than two modes should be included
            model_pdf = max(0,model_pdf);
            % Normalize
            bw = par.ub/2/par.param(C.Bins);
            model_pdf = model_pdf/(sum(model_pdf)*bw);
        end
        model_ccdf = normalize_survivor(ccdfcn(t2));
    catch % if error during computation
        model_pdf = zeros(1,length(t2));
        model_ccdf = [1 zeros(1,length(t2)-1)];
        return;
    end
    % calculate value functions
    if (isstruct(par) && ~isempty(pdf))
        % we do NOT exclude any points when calculating the fits!
        oneminusr2 = 1 - r2(model_pdf,pdf);
        ksd = ksdist(model_ccdf,ccdf);
    end
end

%%
% Check if there is sufficient info to compute the model.
function ok = parameters_available(h)
    ok = false;
    if (~isfield(h,'par') || ~isfield(h.par,'param'))
        return;
    end
    if (~isfield(h.par,'ub') || isempty(h.par.ub) || h.par.ub <= 0)
        return;
    end
    if (any(isempty(h.par.param(1:6))))
        return;
    end
    if (h.par.param(C.Bins) <= 0)
        return;
    end
    ok = true;
end

%%
% Reload spiketrain, compute model, and return.
function reloadcompute(hObj,h)
    h = reloadcompute1(h);
    guidata(hObj,h);
end
    
% Reload spiketrain and compute model.
function h = reloadcompute1(h)
    if (data_available(h))
        h = reload_data(h);
    end
    if (parameters_available(h))
        h = compute_histogram(h);
        h = compute_model(h);
        h = redraw(h);
    end
end

%%
% Recompute model and return.
function recompute(hObj,h)
    h = recompute1(h);
    guidata(hObj,h);
end

%%
% Recompute and redraw model.
function h = recompute1(h)
    if (parameters_available(h))
        h = compute_model(h);
        h = redraw(h);
    end
end

%% Defining Baseline Membrane Potential
%

%%
% Define the threshold distance.
function s = sigma(t, p)
% no if-statements in vectorizable functions
% this function should be callable with t a vector
    % compute tau
    tau = 10^p(C.Log10tau);
    % sigma_0 = 10^p(C.Log10sigma_0);
    sigma_0 = exp(p(C.W)/tau);
    switch p(C.Model)
        case C.Const % Constant
            s = repmat(p(C.Sigma_inf),size(t));
        case C.Exp % Simple exponential
            s = p(C.Sigma_inf) + (sigma_0 - p(C.Sigma_inf)) * exp(-t/tau);
             % truncate for numerical purposes
            s = min(C.ParameterBounds(2,C.Sigma_max),s);
        case C.TruncExp % Truncated exponential
            s = p(C.Sigma_inf) + (sigma_0 - p(C.Sigma_inf)) * exp(-t/tau);
            s = min(p(C.Sigma_max),s);
        case C.SmoothTruncExp % Smooth truncated exponential
            s1 = p(C.Sigma_inf) + (sigma_0 - p(C.Sigma_inf)) * exp(-t/tau);
            % Derivation:
            % s1 = sinf + ex
            % s = -log(exp(-smax))+exp(-s1))
            %   = -log(exp(-smax)[1 + exp(smax - s1)])
            %   = smax - log(1 + exp(smax - s1))
            s = p(C.Sigma_max) - log1p(exp(p(C.Sigma_max)-s1));
        case C.VarSmoothTruncExp % Variable smooth truncated exponential
            s1 = p(C.Sigma_inf) + (sigma_0 - p(C.Sigma_inf)) * exp(-t/tau);
            % Derivation:
            % s = -log(exp(-smax*a))+exp(-s1*a))/a
            %   = -log(exp(-smax*a)[1 + exp(a*(smax - s1))])/a
            %   = smax - log(1 + exp(a*(smax - s1)))/a            
            a = p(C.Theta); % a > 0
            s = p(C.Sigma_max) - log1p(exp(a*(p(C.Sigma_max)-s1)))/a;
        case C.Sigmoid % Sigmoid
            u = (sigma_0 - p(C.Sigma_inf)) * exp(-t/tau);
            s = p(C.Sigma_inf) + ...
                (p(C.Sigma_max) - p(C.Sigma_inf)) * u ./ (1 + u);
        case C.DoubleExp % Double exponential
            s = p(C.Sigma_inf) + ...
                (sigma_0 - p(C.Sigma_inf)) * exp(-t/tau) -...
                p(C.Sigma_max) * exp(-t/p(C.Theta));
    end
end

%%
% Define the derivative of the threshold distance.
function ds = dsigma(t, p)
% no if-statements in vectorized functions
% this function should be callable with t a vector
    % compute tau
    tau = 10^p(C.Log10tau);
    % sigma_0 = 10^p(C.Log10sigma_0);
    sigma_0 = exp(p(C.W)/tau);
    switch p(C.Model)
        case C.Const % Constant
            ds = zeros(size(t));
        case C.Exp % Exponential
            s = p(C.Sigma_inf) + (sigma_0 - p(C.Sigma_inf)) * exp(-t/tau);
            % truncated for numerical purposes
            mask = (s >= C.ParameterBounds(2,C.Sigma_max));
            ds(mask) = 0;
            ds(~mask) = (p(C.Sigma_inf) - s(~mask))/tau;
        case C.TruncExp % Truncated exponential
            s = p(C.Sigma_inf) + (sigma_0 - p(C.Sigma_inf)) * exp(-t/tau);
            mask = (s >= p(C.Sigma_max));
            ds(mask) = 0;
            ds(~mask) = (p(C.Sigma_inf) - s(~mask))/tau;
        case C.SmoothTruncExp % Smooth truncated exponential
            s2 = (sigma_0 - p(C.Sigma_inf)) * exp(-t/tau);
            s1 = p(C.Sigma_inf) + s2;
            % Derivation:
            % s = smax - log(1 + exp(smax - s1))
            % ds = -1/(1 + exp(smax - s1)) * exp(smax - s1) * -ds1
            %    = ds1/(1 + exp(s1 - smax))
            %    = (s1-sinf)*(-1/tau)/(1 + exp(s1 - smax))
            %    = -(s1 - sinf)/tau/(1 + exp(s1 - smax))
            ds = -s2/tau./(1 + exp(s1-p(C.Sigma_max)));
        case C.VarSmoothTruncExp % Variable smooth truncated exponential
            s2 = (sigma_0 - p(C.Sigma_inf)) * exp(-t/tau);
            s1 = p(C.Sigma_inf) + s2;
            % Derivation:
            % s = smax - log(1 + exp(a*(smax - s1)))/a
            % ds = -1/(1 + exp(a*(smax - s1))) * exp(a*(smax - s1)) * -ds1
            % /a
            %    = ds1/(1 + exp(a*(s1 - smax)))/a
            %    = (s1 - sinf)*(-1/tau)/(1 + exp(a*(s1 - smax)))/a
            %    = -(s1 - sinf)/tau/(1 + exp(a*(s1 - smax)))          
            a = p(C.Theta); % a > 0
            ds = -s2/tau/a./(1 + exp(a*(s1-p(C.Sigma_max))));
        case C.Sigmoid % Sigmoid
            u = (sigma_0 - p(C.Sigma_inf)) * exp(-t/tau);
            ds = (p(C.Sigma_inf) - p(C.Sigma_max)) * u ./ (1 + u).^2 / tau; 
        case C.DoubleExp % Double exponential
            ds = -(sigma_0 - p(C.Sigma_inf)) * exp(-t/tau)/tau + ...
                + p(C.Sigma_max) * exp(-t/p(C.Theta))/p(C.Theta);
    end
end

%% Solving Differential Equations for CCDF and PDF
%
% Here we solve the key differential equation
%
% $\dot{\omega} =
% \left(\begin{array}{cc}
% -\mu \nu_1 & -c |\dot{\sigma}| \\
% c |\dot{\sigma}| & -\mu \nu_2 \\
% \end{array} \right)\omega.$

%%
% Right hand side.
function d = domega(t, w, p)
    % RHS of differential equation
    % t and w must be scalars! Perhaps not
    % surprisingly because this is for solving an ODE.
    s = sigma(t,p);
    c = cappr(s) * abs(dsigma(t,p)); % Old sign convention here
    % In a previous model: mu = 10^p(C.Log10mu)
    mu = 10^(-p(C.Log10tau));
    d = [-mu*nuappr(1,s)*w(1) - c*w(2)
         c*w(1) - mu*nuappr(2,s)*w(2)];
end

%%
% Main solver.

% Compute CCDF and PDF by solving an ODE.
% Uses the following entries in par.param:
%      p(C.Integrator), (0 means auto = ode45)
%      p(C.Model), (0 means constant)
%      p(C.Sigma_inf),
%      p(C.Log10tau),
%      p(C.w),
%      p(C.Sigma_max),
%      p(C.Theta),
%      p(C.Bins),
function [ccdf, pdf] = survivor(int, p)
    if (int(1) ~= 0)
        % We always assume that lb equals zero.
        % Otherwise we have problems to define
        % initial values for the DE.
        myerror('survivor: lower bound not zero');
        return;
    end
    s0 = sigma(int(1),p);
    omegainit = [1, 0];
    sinit = [gappr(1,s0), gappr(2,s0)] * omegainit';
    if (p(C.Integrator) == C.Ode4Int) % Fixed step
        % When far away from optimum, use fixed-step integrator
        % NB: ode4 returns table but ode23/ode45 returns function
        if (length(int) > 2) % Return map of tint
            omegatable = oderk4(int, length(int), omegainit, p);
            s = sigma(int, p);
            ccdf = (omegatable(:,1)'.*gappr(1,s) + ...
                 omegatable(:,2)'.*gappr(2,s))/sinit;
            pdf = pdfhelper_fixed(t, int, omegatable, sinit, p);
            if (any(isnan(pdf)))
                myerror('fixed step: Computed NaN while solving ODE');
                return;
            end
        else % Return function if int simple interval
            % These functions will not normally be called many times
            % so it is unnecessary to spend much work on setting them
            % up (e.g., building an interpolation structure
            int = (0:2*p(C.Bins))/p(C.Bins)/2*int(end);
            % We base the step on twice the number of histogram bins
            omegatable = oderk4(int, length(int), omegainit, p);
            ccdf = @(t)survhelper_fixed(t, int, omegatable, sinit, p);
            pdf = @(t)pdfhelper_fixed(t, int, omegatable, sinit, p);
        end
        if (any(isnan(omegatable)))
            myerror('fixed step: Computed NaN while solving ODE');
            return;
        end
    else % Variable step
        % Beware: MATLAB's standard adaptive ODE solvers have a
        % tendency to hang for certain arguments. In particular,
        % ode45 seems to have problems with fmincon and ksdist
        % minimization.
        % We need sufficient accuracy to perform numerical
        % differentiation for the Fisher information.
        % Default: 'RelTol',1e-3,'AbsTol',1e-6
        options = odeset('RelTol',1e-6,...
            ...%for dubugging ...
            ...'Stats','on',...
            'AbsTol',1e-8);
        if (p(C.Integrator) == C.Ode23Int) % variable step with ode23
            omegafcn = ode23(@(t, w)(domega(t, w, p)),...
                int, omegainit, options);
        else % p(C.Integrator) == AutoInt or Ode45Int
            omegafcn = ode45(@(t, w)(domega(t, w, p)),...
                int, omegainit, options);
            % The section below is for debugging:
            % ['sigma_inf=', 'tau=', 'w=', 'sigma0=', 'sigma_max=']
            % [p(C.Sigma_inf), p(C.W), 10^p(C.Log10tau), p(C.Sigma_max), s0]
            % global tmpx tmpy tmpz tmpu tmpv tmpp;
            % tmpx = [0:int(2)/120:int(2)];
            % tmpy = deval(omegafcn,tmpx);
            % tmpu = sigma(tmpx, p);
            % tmpv = dsigma(tmpx, p);
            % tmpp = p;
            % [sigma(10,p),sigma(20,p),sigma(30,p)]
            % [dsigma(10,p),dsigma(20,p),dsigma(30,p)]
        end
        if (length(int) > 2) % Return map of tint
            ccdf = survhelper_variable(int, omegafcn, sinit, p);
            pdf = pdfhelper_variable(int, omegafcn, sinit, p);
        else % Return function if int simple interval
            ccdf = @(t)survhelper_variable(t, omegafcn, sinit, p);
            pdf = @(t)pdfhelper_variable(t, omegafcn, sinit, p);
            % The section below is for debugging:
            % tmpz = ccdf(tmpx);
            % [(ccdf(0.01)-ccdf(0))/0.01, ccdf(90)]
            % 1-[ccdf(1), ccdf(10), ccdf(20)]
            % [pdf(0), pdf(10), pdf(20)]
        end
    end
end

%%
% 4th-order Runge-Kutta ODE solver.
function y = oderk4(int,n,y0,p)
    dt2 = (int(end)-int(1))/(n-1)/2;
    y = zeros(2,n);
    m = zeros(2,4);
    t = int(1) + 2*dt2;
    y(:,1) = y0;
    for i = 2:n
        w = y(:,i-1);
        m(:,1) = domega(t,w,p);
        t = t + dt2;
        m(:,2) = domega(t,w+dt2*m(:,1),p);
        m(:,3) = domega(t,w+dt2*m(:,2),p);
        t = t + dt2;
        m(:,4) = domega(t,w+2*dt2*m(:,3),p);
        y(:,i) = w + (dt2/3)*(m(:,1) + 2*m(:,2) + 2*m(:,3) + m(:,4));
    end
    y = y';
end

%%
% The |*_fixed| procedures are lower order and less accurate,
% but fast and robust. For the CCDF we use cubic interpolation, and
% for the PDF, its derivative, we use a difference approximation.
% The CCDF (tail distribution or complementary cumulative
% distribution function) is
%
% $F_c = 1 - F = g^T \omega / g_0.$
%
% The PDF (frequency function or probability density function) is
%
% $f = \frac{dF}{dt}.$

%%
% Apply tail distribution to time or time series.
function ccdf = survhelper_fixed(t, int, omegatable, sinit, p)
% Vectorized over t
    if (any(isnan(omegatable)))
        myerror(...
'survhelper_fixed_omegatable: Computed NaN when evaluating ODE solution');
    end
    w = interp1(int, omegatable, t, 'cubic','extrap')';
    s = sigma(t, p);
    g1 = gappr(1,s);
    g2 = gappr(2,s);
    ccdf = (g1.*w(1,:) + g2.*w(2,:))/sinit;
    if (any(isnan(ccdf)))
        myerror(...
'survhelper_fixed_ccdf: Computed NaN when evaluating ODE solution');
    end
end

%%
% Apply PDF to time or time series.
function pdf = pdfhelper_fixed(t, int, omegatable, sinit, p)
% Vectorized over t
    ccdf = @(t)survhelper_fixed(t, int, omegatable, sinit, p);
    pdf = -diffr(t,ccdf,int);
    if (any(isnan(pdf)))
        myerror(...
         'pdfhelper_fixed: Computed NaN when evaluating ODE solution');
    end
end

%%
% Differentiate time series.
function df = diffr(t,f,int)
% Differentiate f within the interval int
% Vectorized over t & second-order accurate
    dt = 1e-4;
    mask = (t < int(1) + dt);
    x = t(mask);
    df(mask) = -3*f(x) + 4*f(x + dt) - f(x + 2*dt);
    mask = (t > int(end) - dt);
    x = t(mask);
    df(mask) = 3*f(x) - 4*f(x - dt) + f(x - 2*dt);
    mask = (int(1) + dt <= t) & (t <= int(end) - dt);
    x = t(mask);
    df(mask) = f(x + dt) - f(x - dt);
    df = df/(2*dt);
end

%%
% The '*_variable' procedures are more accurate, but also more
% fragile. 

%%
% Compute survivor function for variable time step solvers.
function F = survhelper_variable(t, omegafcn, sinit, p)
% Vectorized over t
    w = deval(omegafcn, t);
    s = sigma(t, p);
    g1 = gappr(1,s);
    g2 = gappr(2,s);
    F = (g1.*w(1,:) + g2.*w(2,:))/sinit;
    if (any(isnan(F)))
        myerror('variable step: Computed NaN while solving ODE');
    end
end

%%
% The PDF is computed by the exact formula
%
% $f = \frac{dF}{dt} =
% -\left(\dot{g}^T \omega + g^T \dot{\omega}\right) / g_0 =
% -\left(\dot{g}^T + g^T\left(\begin{array}{cc}
% -\mu \nu_1 & -c |\dot{\sigma}| \\
% c |\dot{\sigma}| & -\mu \nu_2 \\
% \end{array} \right)\right) \omega / g_0.$
     
%%
% Compute PDF for variable time step solvers.
function f = pdfhelper_variable(t, omegafcn, sinit, p)
% Vectorized over t
    w = deval(omegafcn, t);
    s = sigma(t, p);
    ds = dsigma(t, p);
    % NB: s and ds can be vectors, so dotwise mult necessary! (cf domega)
    c = cappr(s) .* abs(ds); % Old sign convention
    % In a previous model: mu = 10^p(C.Log10mu);
    mu = 10^(-p(C.Log10tau));
    g1 = gappr(1,s);
    g2 = gappr(2,s);
    a = dgappr(1,s).*ds - g1.*nuappr(1,s)*mu + g2.*c;
    b = dgappr(2,s).*ds - g1.*c - g2.*nuappr(2,s)*mu;
    f = -(a.*w(1,:) + b.*w(2,:))/sinit;
    if (any(isnan(f)))
        myerror('variable step: Computed NaN while solving ODE');
    end
end

%%
% Get PDF (function data); callback from optimize.
function pdf = survpdf(pvars, int, p, fvars, h_inf)
% Vectorized over int
    % Derivative of survivor function
    % pvars are the new tentative values
    p(fvars) = pvars;
    % Set mu from sigma_inf unless locked
    % From v7, mu is set from 1/tau instead
    % p(C.Log10mu) = mumod(p,h_inf);
    p(C.Log10mu) = -p(C.Log10tau);
    % Solve differential equation
    [~, f] = survivor([0, int(end)], p);
    % Generate data
    pdf = f(int);
end

%%
% Get KS distance (scalar); callback from optimize.
function ks = ksdistcdf(ccdf, pvars, t, p, fvars, h_inf)
% NOT vectorized; returns scalar for vector t
    p(fvars) = pvars;
    % Set mu from sigma_inf unless locked
    % From v7, mu is set from 1/tau instead
    % p(C.Log10mu) = mumod(p,h_inf);
    p(C.Log10mu) = -p(C.Log10tau);
    % Find survivor function
    try
        [Fc, ~] = survivor([0 t(end)],p);
        ccdf_data = Fc(t); % t is not equidistant
        if (any(isnan(ccdf_data)))
            myerror('ksdistcdf: Computed NaN while optimizing');
        end
        ks = ksdist(ccdf, normalize_survivor(ccdf_data));
    catch % if error
        ks = 1;
    end
end

%%
% Help functions.

%%
% Set $\mu$ if locked, otherwise derive from tail. (Not used from v7)
function mu = mumod(p,h_inf)
    % Compute log10(mu) = p(C.Log10mu) from sigma_inf = p(C.Sigma_inf)
    % Check if p(C.Log10mu) is locked
    if (p(C.Mu_locked))
        mu = p(C.Log10mu);
    else % otherwise derive from sigma_inf
        mu = log10(h_inf/nuappr(1,p(C.Sigma_inf)));
    end
end

%%
% Compute mean ISI duration from model.
function avg = meanisi(t, sigma_inf, p)
    % Integral of survivor function = mean spike interval
    % Solve the differential equation
    % CANNOT be vectorized
    p(C.Sigma_inf) = sigma_inf;
    try
        [ccdf, ~] = survivor([0, t], p);
        % compute integrated survivor function
        avg = integral(ccdf,0,t);
    catch
        avg = 0;
    end
end

%%
% Coefficient of determination.
function z = r2(f,y)
    z = 1 - sum((f-y).^2)/sum((y-mean(y)).^2);
end

%%
% Kolmogorov-Smirnov distance.
function z = ksdist(ccdf1,ccdf2)
    z = max(abs(ccdf1 - ccdf2));
end

%%
% Normalize CCDF.
function ns = normalize_survivor(s)
    ns = s/s(1);
end

%%
% Compute linearity, i.e. output frequency as a function of
% limiting membrane potential.
function [inl, dnl, sigmalist, freqlist, smin, smax] = ...
    vfgain(t,param)
    % Display linearity by computing 1/mean(isi) for range of sigma_inf
    % including
    % INL = Integral Nonlinearity
    % DNL = Differential Nonlinearity
    sigmalist = -4:0.1:4;
    smin = 21; % find(-2 == sigmalist);
    smax = 51; % find(1 == sigmalist);
    % meanisi cannot be vectorized!
    freqlist = 1000./...
        arrayfun(@(sigma_inf)meanisi(t,sigma_inf,param),sigmalist);
    % DNL = max(|dy/dx/a - 1|)
    % INL = max(|(y-b)/a - x|)
    inl = integralnonlinearity(sigmalist(smin:smax),freqlist(smin:smax));
    dnl = differentialnonlinearity(sigmalist(smin:smax),...
        freqlist(smin:smax));
end

%%
% Compute integral non-linearity.
function inl = integralnonlinearity(sigmalist, freqlist)
    coeff = pinv([sigmalist' ones(length(sigmalist),1)])* freqlist';
    inl = max(abs((freqlist-coeff(2))/coeff(1) - sigmalist));
end

%%
% Compute differential non-linearity.
function dnl = differentialnonlinearity(sigmalist, freqlist)
    coeff = pinv([sigmalist' ones(length(sigmalist),1)])* freqlist';
    dnl = max(abs((freqlist(2:end)-freqlist(1:end-1))/ ...
                  (sigmalist(2:end)-sigmalist(1:end-1))/coeff(1) - 1));
end

%% Menu callbacks
%

%%
% *File menu.*

function file_tag_Callback(~, ~, ~)
end

%%
% Reset input parameters.
function new_tag_Callback(hObject, ~, h)
    global busycount;
    % reset
    cla(h.axes1);
    h = myrmfield(h,'ccdf');
    h = myrmfield(h,'pdf');
    h = myrmfield(h,'isi');
    set(h.text11,'String','');
    h.par = myrmfield(h.par,'file'); 
    set(h.edit2,'String','');   % bins
    h.par.param(C.Bins) = -1;
    set(h.edit3,'String','');   % ub
    h.par = myrmfield(h.par,'ub');
    set(h.edit11,'String','');  % units
    h.par = myrmfield(h.par,'units');
    set(h.edit12,'String','');  % outliers
    h.par = myrmfield(h.par,'outliers');
    set(h.edit16,'String','');  % tail
    h.par = myrmfield(h.par,'ttail');
    set(h.checkbox7,'Value',1); % xstationary
    h.par.xstationary = 1;
    guidata(hObject,h);
    % reset busy indicator
    busycount = 1;
    busy(false);
end

%%
% Remove a field if it exists.
function struc = myrmfield(struc,name)
    if (isfield(struc,name))
        struc = rmfield(struc,name);
    end
end

%%
% Open file command.
function open_tag_Callback(hObject, ~, h)
    [file, path] = uigetfile([h.path '\\*.*'],'Load data from');
    busy(true);
    if (fileok(file))
        h.path = path;
        h.origfile = file;
        h = loadspiketrain(h,file);
    end
    busy(false);
    guidata(hObject,h);
end

%%
% Print screen command (to PNG).
function print_screen_tag_Callback(hObj, ~, h)
    [~, fname, ~] = fileparts(h.origfile);
    if (~isempty(fname))
        gendoc1(h,fname);
    end
end

%%
% Manual print screen command.
function print_tag_Callback(~, ~, handles)
    set(handles.figure1, 'PaperOrientation', 'landscape', ...
                         'PaperPositionMode', 'auto');
    printpreview(handles.figure1);
end

%%
% Save command.
function save_tag_Callback(hObject, eventdata, h)
    [~, name, ext] = fileparts(h.origfile);
    % if this was a datafile, then only "save as" is ok
    if (~strcmp(ext,'.mat') && ~strcmp(ext,'.bak'))
        save_as_tag_Callback(hObject, eventdata, h);
        return;
    end;
    busy(true);
    saveback(h,h.path,h.origfile);
    busy(false);
    guidata(hObject,h);
end

%%
% Save as command.
function save_as_tag_Callback(hObject, ~, h)
    % Save all *parameters* under handles.par
    [file, path] = uiputfile([h.path '\\*.mat'],'Save parameters as');
    if (fileok(file))
        h.path = path; % Remember path
        h.origfile = file; % Remember param file
        save_it(fullfile(path,file),h);
        set(h.text11,'String',...
            strcat(h.origfile,' (',h.par.file,')')); % filename
    end
    % reload by: handles.par = load(pathfile)
    guidata(hObject,h);
end

%%
% Save diagram as data table.
function save_diagram_tag_Callback(~, ~, handles)
    % Save diagram data
    % PDF, CDF, or Linearity depending on radio buttons
    if (~data_available(handles)) % ISI data unavailable
        return;
    end
    [file, path] = uiputfile('*.txt',...
        'Save diagram data as table in'); % get filename
    if (~fileok(file))
        % If cancelled
        return;
    end
    save_data1(handles,file,path);
end

%%
% *Tools menu.*
function tools_tag_Callback(~, ~, ~)
end

%%
% *Batch processing menu.*
function batch_tag_Callback(~, ~, ~)
end

%%
% Batch estimate parameters.
function estimate_parameters_tag_Callback(~, ~, h)
    apply_to_batch(h,@(fname)estpar1(fname,false));
end

%%
% Batch estimate parameters and save back.
function estimate_parameters_and_save_back_Callback(~, ~, h)
    apply_to_batch(h,@(fname)estpar1(fname,true));
end
  
%%
% Batch estimate errors.
function estimate_variances_tag_Callback(~, ~, h)
    apply_to_batch(h,@(fname)estvar1(fname,false));
end
  
%%
% Batch estimate errors and save back.
function estimate_variances_and_save_back_Callback(~, ~, h)
    apply_to_batch(h,@(fname)estvar1(fname,true));
end

%%
% Batch generate PNG screen shot documents.
function generate_documents_tag_Callback(~, ~, h)
    apply_to_batch(h,@load_and_gendoc1);
end

%%
% Apply procedure to batch of files.
function apply_to_batch(h,proc)
    [file, path] = uigetfile([h.path '\\*.txt'],...
        'List of parameter files to process');
    if (~fileok(file))
        return;
    end
    try 
        fid = fopen(fullfile(path,file));
        flist = textscan(fid,'%s %*[^\n]');
        fclose(fid);
    catch % Error when loading file
        myfprintfopen(h,...
    '\napply_to_batch: Error when trying to load file %s\n',...
            fullfile(path,file));
        beep;
        return;
    end
    h.path = path;
    busy(true);
    myfprintfopen(h,'\nBatch processing started %s...\n',datestr(now));
    cellfun(proc,flist{1});
    h = guidata(gcbo);
    myfprintfopen(h,'\nBatch processing completed %s.\n',datestr(now));
    busy(false);
    set(h.edit10,'String',1);
    drawnow;
    guidata(gcbo,h);
end

%%
% Estimate parameters of one file.
function dummy = estpar1(fname,saveback_flag)
    dummy = 0;
    % load the file
    h = loadfile(fname);
    if (isempty(h))
        return
    end
    % get iterations
    n = str2double(get(h.edit10,'String'));
    % multistart optimization using fixed step by default
    h = optimize(h,n);
    h = recompute1(h);
    % plus one ordinary optimization using default variable step
    h = optimize(h,1);
    h = recompute1(h);
    h = clear_rmse(h);
    % save back
    if (saveback_flag)
        saveback(h,h.path,fname);
    end
    % Restore iterator
    set(h.edit10,'String',n);
    guidata(gcbo,h);
end

%%
% Estimate MSE of one file.
function dummy = estvar1(fname,saveback_flag)
    dummy = 0;
    % load the file
    h = loadfile(fname);
    if (isempty(h))
        return
    end
    % get iterations
    n = str2double(get(h.edit10,'String'));
    if (n < 2)
        n = 2;
        set(h.edit10,'String',n)
    end
    % multistart bootstrap resampling using default variable step
    h = bootstrap(h,n);
    h = recompute1(h);
    % save back
    if (saveback_flag)
        saveback(h,h.path,fname);
    end
    % Restore iterator
    set(h.edit10,'String',n);
    guidata(gcbo,h);
end
 
%%
% Compute indicators based on Fisher Information.
function crlb_tag_Callback(hObject, ~, h)
    fid = fopen(h.logfile,'a');
    busy(true);
    [sd, mvars, cond, fisherinfo] = compute_crlb(h);
    m = sum(mvars);
    myfprintf(fid,'\nFisher information matrix (condition %.1e):\n',...
        round(cond));
    arrayfun(@(x)myfprintf(fid,'%s',x),cell2mat(C.ParamName(mvars)));
    myfprintf(fid,'\n');
    myprintmatrix(fid,fisherinfo);
    myfprintf(fid,'has eigenvectors (rows)');
    myfprintf(fid,' and corresponding eigenvalues\n');
    [V,D] = eig(fisherinfo);
    myprintmatrix(fid,[V' diag(D)]);
    myfprintf(fid,'and inverse:\n');
    myprintmatrix(fid,inv(fisherinfo));
    myfprintf(fid,'Parameters:\n');
    arrayfun(@(x)myfprintf(fid,'%s',x),cell2mat(C.ParamName(mvars)));
    myfprintf(fid,'\n');
    arrayfun(@(x)myfprintf(fid,'%-12f',x),h.par.param(mvars));
    myfprintf(fid,'\nCramer-Rao Lower Bounds on standard deviation:\n');
    arrayfun(@(x)myfprintf(fid,'%-12f',x),sd);
    myfprintf(fid,'\n');
    busy(false);
    beep;
    if (fid ~= -1) % if file opened ok
        fclose(fid);
    end
    guidata(hObject,h);
end
    
%%
% Synthesize a spike train.
function synthesize_tag_Callback(hObject, ~, h)
    if (parameters_available(h))
        busy(true);
        n = str2double(get(h.edit10,'String'));
        if (n < 2)
            n = length(h.isi);
        end
        set(h.edit10,'String',1);
        the_data = synthetic_isi(h.par, n);
        h = myrmfield(h,'origfile');
        h.par.file = '<synthetic spiketrain>';
        set(h.text11,'String',h.par.file);
        h = parse_data(h, the_data');
        h = compute_histogram(h);
        h = compute_model(h);
        h = redraw(h);
        busy(false);
    end
    h = clear_rmse(h);
    guidata(hObject,h);
end

%%
% Batch print parameters.
function print_parameters_tag_Callback(~, ~, h)
    apply_to_batch(h,@print_parameters);
end

%%
% Print parameters.
function print_parameters(fname)
    % load the file
    h = loadfile(fname);
    if (isempty(h))
        return;
    end
    p = h.par.param;
    [~, file, ~] = fileparts(fname);
    [sd, ~, fisher_cond, ~] = compute_crlb(h);
    % Use a full representation of SD for compatibility
    mvars = unlocked_model_vars(h.par);
    sd2 = zeros(1, C.NoParams);
    sd2(find(mvars)) = sd([1:sum(mvars)]);
    [inl, dnl] = vfgain(h.par.outliers,p);
    myfprintfopen(h,...
        '# Recording Profile ISI-length 1-R2 KSdist Mean SD Entropy FI-cond');
    myfprintfopen(h,' INL DNL iterations');
    myfprintfopen(h,' Sigma_max RMSE CRLB');
    myfprintfopen(h,' Sigma_inf RMSE CRLB');
    myfprintfopen(h,' Log10(tau) RMSE CRLB');
    myfprintfopen(h,' W RMSE CRLB');
    myfprintfopen(h,' Theta RMSE CRLB');
    myfprintfopen(h,' Tau\n');
    myfprintfopen(h,...
        '%s %s %d %g %g %g %g %g %g %g %g %d',...
        file,...
        cell2mat(C.ShortModelName(p(C.Model))),...
        length(h.isi),...
        h.oneminusr2,...
        h.ksdist,...
        mean(h.isi),...
        std(h.isi),...
        h.entropy,...
        fisher_cond,...
        inl,...
        dnl,...
        h.par.iterations);   
    myfprint_par(C.Sigma_max, sd2, h);
    myfprint_par(C.Sigma_inf, sd2, h);
    myfprint_par(C.Log10tau, sd2, h);
    myfprint_par(C.W, sd2, h);    
    myfprint_par(C.Theta, sd2, h);
    myfprintfopen(h, ' %g\n', 10^p(C.Log10tau));
end

%%
% Help function for printing parameters.
function myfprint_par(code, sd2, h)
    p = h.par.param;
    % Check if parameter is included in p(C.Model) 
    if C.ModelVars(p(C.Model),code)
        myfprintfopen(h, ' %g %g %g', p(code), h.par.rmse(code), sd2(code))
    else % parameter unavailable
        myfprintfopen(h, ' %g %g %g', 0.0, 0.0, 0.0);
    end
end

%%
% Batch save diagram data to file.
function batch_save_diagram_tag_Callback(~, ~, h)
    apply_to_batch(h,@save_data);
end

%%
% Save diagram data to file.
function save_data(fname)
    % load the file
    h = loadfile(fname);
    if (isempty(h))
        return;
    end
    [~, file, ext] = fileparts(fname);    
    save_data1(h, file, h.path);
end

function save_data1(handles, file, path)
    % Save diagram data, low-level funtion.
    % PDF, CDF, or Linearity depending on radio buttons
    if (~data_available(handles)) % ISI data unavailable
        return;
    end
    t2 = plotpoints(handles.par);
    switch handles.diagtype
        case C.CDFDiag % CDF: t, recording (CDF), model (CDF)
            table = [t2; handles.ccdf; handles.model_ccdf]';
        case C.PDFDiag % PDF: t, KDE, model, histogram, sigma
            kde = handles.pdf; % recording (KDE)
            model = handles.model_pdf; % model (PDF)
            histo(1:length(t2)) = 0;
            histo(2:2:end) = handles.histo; % histogram
            s = sigma(t2,handles.par.param); % sigma
            table = [t2; kde; model; histo; s]';
        case C.LinearityDiag % Linearity: sigma, freq, sigma_inf, f(sigma_inf)
            table = [handles.sigma; handles.f]';
            % Save the current spot as well
            table(:,3) = handles.par.param(C.Sigma_inf);
            table(:,4) = 1000/meanisi(handles.par.outliers,...
                handles.par.param(C.Sigma_inf),handles.par.param);
    end
    save(fullfile(path,strcat(file,'.txt')),'table','-ascii');
end

%%
% *Settings menu.*
function settings_tag_Callback(~, ~, ~)
end

%%
% Auto step setting.
function auto_step_tag_Callback(hObject, ~, handles)
    set(hObject,'Checked','on');
    set(handles.fixed_step_integrator_tag,'Checked','off');
    set(handles.variable_step_integrator_tag,'Checked','off');
    set(handles.ode45_tag,'Checked','off');
    handles.par.param(C.Integrator) = C.AutoInt;
    guidata(hObject,handles);
end

%%
% Fixed step setting, using 4th-order RK solver (robust).
function fixed_step_integrator_tag_Callback(hObject, ~, handles)
    set(hObject,'Checked','on');
    set(handles.auto_step_tag,'Checked','off');
    set(handles.variable_step_integrator_tag,'Checked','off');
    set(handles.ode45_tag,'Checked','off');
    handles.par.param(C.Integrator) = C.Ode4Int;
    guidata(hObject,handles);
end

%%
% Use variable step RK solver ode23.
function variable_step_integrator_tag_Callback(hObject, ~, handles)
    set(hObject,'Checked','on');
    set(handles.auto_step_tag,'Checked','off');
    set(handles.ode45_tag,'Checked','off');
    set(handles.fixed_step_integrator_tag,'Checked','off');
    handles.par.param(C.Integrator) = C.Ode23Int;
    guidata(hObject,handles);
end

%%
% Use variable step solver ode45 (fast and accurate but fragile).
function ode45_tag_Callback(hObject, ~, handles)
    set(hObject,'Checked','on');
    set(handles.auto_step_tag,'Checked','off');
    set(handles.fixed_step_integrator_tag,'Checked','off');
    set(handles.variable_step_integrator_tag,'Checked','off');
    handles.par.param(C.Integrator) = C.Ode45Int;
    guidata(hObject,handles);
end

%%
% Use only a single processor.
function single_core_tag_Callback(hObject, ~, handles)
    global multicore;
    set(hObject,'Checked','on');
    set(handles.multicore_tag,'Checked','off');
    multicore = false;
    guidata(hObject,handles);
end

%%
% Use parallel processing with all processor cores.
function multicore_tag_Callback(hObject, ~, handles)
    global multicore;
    set(hObject,'Checked','on');
    set(handles.single_core_tag,'Checked','off');
    multicore = true;
    guidata(hObject,handles);
end

%%
% Set logfile.
function set_logfile_tag_Callback(hObject, ~, handles)
    [file, path] = uiputfile(handles.logfile,'Use logfile');
    if (fileok(file))
        handles.logfile = fullfile(path,file);
    end
    guidata(hObject,handles);
end

%% Speed critical special functions
% This code is commented out because equivalent,
% but faster versions written in C/MEX is used.

%{

function nu = nuappr(n, s)
    persistent pp;
    if (isempty(pp))
        x = -10:20/1024:10
        nu1 = [...];   % Large table here
        nu2 = [...];   % Large table here
        pp = {spline(x,nu1), spline(x,nu2)};
    end
    nu = ppval(pp{n},s);
end

function c = cappr(s)
    persistent pp;
    if (isempty(pp))
        x = -10:20/1024:10
        c12 = [...];   % Large table here
        pp = spline(x,c12);
    end
    % Always greater than zero
    c = ppval(pp,s);
end

% This function is the integrated normalized eigenfunction divided by
% sqrt(sqrt(2 * pi))
function g = gappr(n, s)
    persistent pp;
    if (isempty(pp))
        x = -10:20/1024:10
        g1 = [...];   % Large table here
        g2 = [...];   % Large table here
        pp = {spline(x,g1), spline(x,g2)};
    end
    g = ppval(pp{n},s);
end

% This function is the normalized eigenfunction divided by
% sqrt(sqrt(2 * pi))
function dg = dgappr(n, s)
    persistent pp;
    if (isempty(pp))
        x = -10:20/1024:10
        dg1 = [...];   % Large table here
        dg2 = [...];   % Large table here
        pp = {spline(x,dg1), spline(x,dg2)};
    end
    dg = ppval(pp{n},s);
end

%}

%% GUI
% The code in this section is boring, but needed
% by the grapical user interface.

%%
% Change between PDF, CDF, and linearity display.
function uipanel10_SelectionChangeFcn(hObject, ~, handles)
    if (hObject == handles.radiobutton10) % cdf
        handles.diagtype = C.CDFDiag;
    elseif (hObject == handles.radiobutton9) % pdf
        handles.diagtype = C.PDFDiag;
    elseif (hObject == handles.radiobutton18) % linearity
        handles.diagtype = C.LinearityDiag;
    end
    handles = redraw(handles);
    guidata(hObject,handles);
end

%%
% Toggle busy LED indicator.
function busy(on)
    global busycount;
    h = guidata(gcbo);
    axes(h.axes4);
    if (on)
        busycount = busycount + 1;
        image(h.red);
    else
        busycount = busycount - 1;
        if (busycount == 0)
            image(h.green);
        end
    end
    drawnow;
end

%%
% Indicate error.
function warning()
    h = guidata(gcbo);
    axes(h.axes4);
    image(h.yellow);
    drawnow;
end

%%
% Generate error message.
function myerror(msg)
    warning();
    error(msg);
end

%%
% Set parameters on display.
function h = set_display_par(h)
    set(h.edit2,'String',h.par.param(C.Bins));
    set(h.edit3,'String',h.par.ub);
    h = display_params(h);
    h = display_rmse(h);
    for k=1:C.NoParams
        set(h.sliders(k),'Value',h.par.param(k));
    end
    if (isfield(h.par,'units'))
        set(h.edit11,'String',h.par.units);
    end
    if (isfield(h.par,'outliers'))
        set(h.edit12,'String',h.par.outliers);
    end
    if (isfield(h.par,'ttail'))
        set(h.edit16,'String',h.par.ttail);
    end
    if (isfield(h.par,'xstationary'))
        set(h.checkbox7,'Value',h.par.xstationary);
    end
    if (~data_available(h))
        set(h.text9,'String','');
        set(h.text10,'String','');
    else
        set(h.text9,'String',sprintf('%.6f',h.oneminusr2));
        set(h.text10,'String',sprintf('%.6f',h.ksdist));
    end
end

%%
% Display all parameters.
function h = display_params(h)
    arrayfun(@(n)display_one_param(h,n),1:C.NoParams);
end

%%
% Display one parameter.
function h = display_one_param(h,n)
    if (C.IsLogParam(n))
        val = 10^h.par.param(n);
    else
        val = h.par.param(n);
    end
    set(h.edits(n),'String',sprintf('%#.3g',val));
end

%%
% Toggle parameter locks.
function docheckbox(hObject, handles, n)
    p = handles.lock(n);
    handles.par.locked(n) = (get(p,'Value') == get(p,'Max'));
    if (n == C.Log10mu && isfield(handles.par,'locked'))
        handles.par.param(C.Mu_locked) = handles.par.locked(C.Log10mu);
    elseif (n == C.Log10mu)
        handles.par.param(C.Mu_locked) = 0;
    end
    guidata(hObject,handles);
end

%%
% Display RMSE errors.
function h = display_rmse(h)
    if (isfield(h.par,'rmse'))
        set(h.errors(C.Sigma_max),'String',sprintf('%#.3g',...
            h.par.rmse(C.Sigma_max)));
        set(h.errors(C.Sigma_inf),'String',sprintf('%#.3g',...
            h.par.rmse(C.Sigma_inf)));
        set(h.errors(C.Log10tau),'String',sprintf('%#.3g%%',...
            (10^h.par.rmse(C.Log10tau)-1)*100));
        set(h.errors(C.Log10mu),'String',sprintf('%#.3g%%',...
            (10^h.par.rmse(C.Log10mu)-1)*100));
        set(h.errors(C.W),'String',sprintf('%#.3g',...
            h.par.rmse(C.W)));
        set(h.errors(C.Theta),'String',sprintf('%#.3g',...
            h.par.rmse(C.Theta)));
        if (isfield(h.par,'iterations'))
            set(h.text30,'String',sprintf('RMSE@n=%d',h.par.iterations));
        end
    end
end

%%
% Toggle parameter locks.
function checkbox1_Callback(hObject, ~, handles)
    docheckbox(hObject, handles, 1);
end

function checkbox2_Callback(hObject, ~, handles)
    docheckbox(hObject, handles, 2);
end

function checkbox3_Callback(hObject, ~, handles)
    docheckbox(hObject, handles, 3);
end
    
function checkbox4_Callback(hObject, ~, handles)
    docheckbox(hObject, handles, 4);
end
    
function checkbox5_Callback(hObject, ~, handles)
    docheckbox(hObject, handles, 5);
end
    
function checkbox6_Callback(hObject, ~, handles)
    docheckbox(hObject, handles, 6);
end

%%
% Handle THE project button.
function pushbutton3_Callback(~, ~, ~) % THE project button
    dos('explorer http://www.thehandembodied.eu');
end

%%
% Select auxiliary diagrams.
function uipanel12_SelectionChangeFcn(hObject, ~, h)
    % Don't shift up conditional histograms
    if (h.queue(1) ~= C.CondHistogram)
        h.queue(2:3) = h.queue(1:2);
    end
    % interpret the radio buttins
    if (hObject == h.radiobutton13)
        h.queue(1) = C.MembranePot;
    elseif (hObject == h.radiobutton26)
        h.queue(1) = C.ThresholdDist;
    elseif (hObject == h.radiobutton14)
        h.queue(1) = C.SegmentMean;
    elseif (hObject == h.radiobutton15)
        h.queue(1) = C.CondMean;
    elseif (hObject == h.radiobutton16)
        h.queue(1) = C.CondHistogram;
    elseif (hObject == h.radiobutton17)
        h.queue(1) = C.Autocorrel;
    elseif (hObject == h.radiobutton19)
        h.queue(1) = C.MuEst;
    end        
    h = redraw_suppl(hObject,h);
    drawnow;
    guidata(hObject,h);
end

%%
% Called when model is changed.
function popupmenu2_Callback(hObject, ~, h) % Model changed
    h.par.param(C.Model) = get(hObject,'Value');
    h = change_model(h);
    recompute(hObject,h);
end

%%
% Change visibility of an object.
function setvisibility(v,mask)
    set(v(mask),'Visible','on');
    set(v(~mask),'Visible','off');
end
    
%%
% Change model and corresponding visibility of controls.
function h = change_model(h) % Change model
    set(h.popupmenu2,'Value',h.par.param(C.Model));
    if (get(h.checkbox8,'Value'))
        h = slider_visibility(h);
    end
    mask = model_vars(h.par);
    setvisibility(h.edits,mask);
    setvisibility(h.lock,mask);
    setvisibility(h.errors,mask);
end

%%
% Clear RMSE error fields.
function h = clear_rmse(h)
    set(h.errors,'String','');
    h.par = myrmfield(h.par,'rmse');
    set(h.text30,'String','RMSE');
    h.par = myrmfield(h.par,'iterations');
end
    
%%
% Set slider visibility.
function h = slider_visibility(h) 
    setvisibility(h.sliders,model_vars(h.par));
end

%%
% Set diagram visibility.
function h = diagram_visibility(h,b) 
    set(h.axes7,'Visible',b);
    set(get(h.axes7,'Children'),'Visible',b);
    set(h.axes8,'Visible',b);
    set(get(h.axes8,'Children'),'Visible',b);
end

%%
% Switch between sliders and diagrams.
function checkbox8_Callback(hObject, ~, h)
    if (get(hObject,'Value'))
        h = diagram_visibility(h,'off');
        h = slider_visibility(h);
    else
        h = diagram_visibility(h,'on');
        set(h.sliders,'Visible','off')
    end
    if (data_available(h) && get(h.checkbox8,'Value') == 0)
        h = draw_subgraph(h.axes7,h,h.queue(3));
        h = draw_subgraph(h.axes8,h,h.queue(2));
    end
    guidata(hObject,h);
end

%%
% xstationary changed.
function checkbox7_Callback(hObject, ~, h) 
    h.par.xstationary = get(hObject,'Value');
    reloadcompute(hObject,h);
end

%%
% Bandwidth changed.
function edit2_Callback(hObject, ~, h) 
    h.par.param(C.Bins) = str2double(get(hObject,'String'));
    h = recompute_bw(h);
    reloadcompute(hObject,h);
end
    
%%
% Upper bound changed.
function edit3_Callback(hObject, ~, h) 
    h.par.ub = str2double(get(hObject,'String'));
    h = recompute_bw(h);
    reloadcompute(hObject,h);
end

%%
% Set parameters from edit fields.
function h = setparam(hObject,h,n)
    if (C.IsLogParam(n))
        h.par.param(n) = log10(str2double(get(hObject,'String')));
    else
        h.par.param(n) = str2double(get(hObject,'String'));
    end
    set(h.sliders(n),'Value',h.par.param(n));
    h = clear_rmse(h);
    recompute(hObject,h);
end
    
%%
% Called when edit fileds are changed.
function edit4_Callback(hObject, ~, h)
    setparam(hObject,h,1);
end

function edit5_Callback(hObject, ~, h)
    setparam(hObject,h,2);
end

function edit6_Callback(hObject, ~, h)
    setparam(hObject,h,3);
end

function edit7_Callback(hObject, ~, h)
    setparam(hObject,h,4);
end
    
function edit8_Callback(hObject, ~, h)
    setparam(hObject,h,5);
end
  
function edit9_Callback(hObject, ~, h)
    setparam(hObject,h,6);
end

function edit10_Callback(~, ~, ~) % Number of multistarts changed
end
    
function edit11_Callback(hObject, ~, h) % Units changed
    h.par.units = str2double(get(hObject,'String'));
    reloadcompute(hObject,h);
end

function edit12_Callback(hObject, ~, h) % Outliers changed
    h.par.outliers = str2double(get(hObject,'String'));
    reloadcompute(hObject,h);
end
    
function edit16_Callback(hObject, ~, h) % Tail changed
    h.par.ttail = str2double(get(hObject,'String'));
    reloadcompute(hObject,h);
end

%%
% Set edit field to slider value
function setslider(hObject,h,n)
    h.par.param(n) = get(hObject,'Value');
    h = set_display_par(h);
    h = display_params(h);
    h = clear_rmse(h);
    recompute(hObject,h);
end

%%
% Dummy functions called upon slider movement.
function slider1_Callback(hObject, ~, h)
    setslider(hObject,h,1);
end
    
function slider2_Callback(hObject, ~, h)
    setslider(hObject,h,2);
end

function slider3_Callback(hObject, ~, h)
    setslider(hObject,h,3);
end

function slider4_Callback(hObject, ~, h)
    setslider(hObject,h,4);
end

function slider5_Callback(hObject, ~, h)
    setslider(hObject,h,5);
end

function slider6_Callback(hObject, ~, h)
    setslider(hObject,h,6);
end

%%
% Dummy functions called upon creation of controls.
function edit2_CreateFcn(~, ~, ~)
end

function edit3_CreateFcn(~, ~, ~)
end

function edit4_CreateFcn(~, ~, ~)
end

function edit5_CreateFcn(~, ~, ~)
end

function edit6_CreateFcn(~, ~, ~)
end

function edit7_CreateFcn(~, ~, ~)
end
    
function edit8_CreateFcn(~, ~, ~)
end

function edit9_CreateFcn(~, ~, ~)
end
    
function edit10_CreateFcn(~, ~, ~)
end

function edit11_CreateFcn(~, ~, ~)
end
    
function edit12_CreateFcn(~, ~, ~)
end
    
function edit16_CreateFcn(~, ~, ~)
end

function edit18_CreateFcn(~, ~, ~)
end

function edit19_CreateFcn(~, ~, ~)
end

function edit20_CreateFcn(~, ~, ~)
end

function edit21_CreateFcn(~, ~, ~)
end

function edit22_CreateFcn(~, ~, ~)
end

function edit23_CreateFcn(~, ~, ~)
end

function slider1_CreateFcn(~, ~, ~)
end
    
function slider2_CreateFcn(~, ~, ~)
end
    
function slider3_CreateFcn(~, ~, ~)
end
    
function slider4_CreateFcn(~, ~, ~)
end

function slider5_CreateFcn(~, ~, ~)
end
    
function slider6_CreateFcn(~, ~, ~)
end

function popupmenu2_CreateFcn(~, ~, ~)
end
