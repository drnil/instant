%%
% Constants for INSTANT.

classdef C
    properties (Constant)
    % Number of parameters
        NoParams = 6;
    % Model parameters
        Sigma_max = 1; 
        Sigma_inf = 2;
        Log10tau = 3;
        Log10mu = 4;
        W = 5;
        Theta = 6;
    % Old model parameters
        Log10sigma_0 = 5;
        Sigma_0old = 1; 
        Sigma_infold = 2;
        Log10tauold = 3;
        Log10muold = 4;
        Wold = 5;
        Thetaold = 6;
    % Control parameters
        Model = 7;
        Mu_locked = 8;
        Integrator = 9;
        BW = 10;
        Bins = 10;
    % Model numbers
        Const = 1;
        Exp = 2;
        TruncExp = 3;
        SmoothTruncExp = 4;
        Sigmoid = 5;
        DoubleExp = 6;
        VarSmoothTruncExp = 7;
    % Model names
        ModelName = {...
            'Constant',...
            'Exponential',...
            'Truncated Exponential',...
            'Smooth Truncated Exponential',...
            'Sigmoid',...
            'Double Exponential',...
            'Variable Smooth Truncated Exponential'};
    % Short model names
        ShortModelName = {...
            'Const',...
            'Exp',...
            'TruncExp',...
            'SmoothTruncExp',...
            'Sigmoid',...
            'DoubleExp',...
            'VarSmoothTruncExp'};        
    % Parameter names
        ParamName = {...
            'sigma_max   ',...
            'sigma_inf   ',...
            'log10(tau)  ',...
            'log10(mu)   ',...
            'w           ',...
            'theta       '};
    % Set up parameter bounds
        ParameterBounds =...
            [0 -4 -2 -2  -5  0.1
             9  6  2  2  50 10.0];
    % Parameter defaults
        ParamDefaults =...
            [4 -1  1 -1  1  1];
    % Model variables
        ModelVars = logical(...
            [0 1 1 0 0 0
             0 1 1 0 1 0
             1 1 1 0 1 0
             1 1 1 0 1 0
             1 1 1 0 1 0
             1 1 1 0 1 1
             1 1 1 0 1 1]);
        NonMuVars = logical(...
            [1 1 1 0 1 1]);
        IsLogParam = logical(...
            [0 0 1 1 0 0]);
    % Integrators
        AutoInt = 0;
        Ode4Int = 1;
        Ode23Int = 2;
        Ode45Int = 3;
    % Diagram type
        PDFDiag = 0;
        CDFDiag = 1;
        LinearityDiag = 2;
    % Subgraph titles
        SubgraphTitle = {...
            'Membrane Potential',...
            'Threshold Distance',...
            'Segment Mean (stationarity test)',...
            'Conditional Mean (independence test)',...
            'Conditional Histogram (independence test)',...
            'Autocorrelation (independence test)',...
            'Estimate of {\it\mu } from tail'};
    % Subgraph types
        MembranePot = 1;
        ThresholdDist = 2;
        SegmentMean = 3;
        CondMean = 4;
        CondHistogram = 5;
        Autocorrel = 6;
        MuEst = 7;
    % Histogram coloring
        HistoFaceColor = [.8,.8,.8];
        HistoEdgeColor = [.6,.6,.6];
        HistoFaceColorDepend = [.9,.9,1];
        HistoEdgeColorDepend = [.5,.5,1];
    % Various
        Version = 7.0;
        Date = ' ';
        Chunksize = 300; % Max number of iterations to do in parallel
        DefaultBootstrapIterations = 300;
        DefaultOptimizeIterations = 300;
        ContMax = 1000; % Number of test points for finding function max
        LineWidth = 1.5;
        ThinLineWidth = 1;
        LinLength = 20;
   end
end
