/* Lagrange Interpolation Using Instruction Level Parallelism
 * ==========================================================
 * Martin Nilsson & Co @ RISE (formerly SICS), 2015-05-12

 This code works especially well for periodic functions.
 The table size must be a power of 2. Call by, e.g.:

 #if __STDC_VERSION__ == 199901L
    // C99 or later
    double * restricted y, * restricted z;
 #else
    // before C99
    double *y, *z;
 #endif
 ...
 #pragma omp parallel for
    for (i=0; i<mrows*ncols; i++) {
        INTERPOLATE_ORDER6(y[i],z[i],table,XMIN,INVDX,LOG2SIZE);
    }

 Coding advice from RISE colleagues:
 * - Don't use division! (KFF, FD)
 * - Don't trust 'inline' to really become inline (MB, KFF);
 *   use static declaration on procedures if possible (KFF, FD)
 * - There is a trade-off between parfor and higher-level parallelism
 *   which will be handled by future versions of OpenMP (MB)
 * - Use larger tables if possible, but don't risk cache misses (LR)
 * - Use keyword 'restricted' in (C99) pointer declaration (MB)
 * - SIMDfy the code (PJ)
 * - Put bounds checking in a separate loop (KFF)
 * - Conditionals should not be included in loop (KFF)
 
KFF = Karl-Filip Fax�n
FD = Frej Drejhammar
MB = Mats Brorsson
LR = Lars Rasmusson
PJ = Peter Jonsson

*/

#define INTERPOLATE_MASK    ((2<<(LOG2SIZE)) - 1)

#define INTERPOLATE_ORDER6(X,Y,TABLE,XMIN,INVDX,LOG2SIZE)           \
{                                                                   \
    double q, d1, d2, d3, d4, d5, d6, d16, d25, d34, s1, s2, s3;    \
    unsigned int n, m1, m2, m3, m4, m5, m6, m7, m8;                 \
    q = (X-(XMIN))*(INVDX);                                         \
    n = floor(q);                                                   \
    m1 = (n-2) & INTERPOLATE_MASK;                                  \
    m2 = (n-1) & INTERPOLATE_MASK;                                  \
    m3 = (n-0) & INTERPOLATE_MASK;                                  \
    m4 = (n+1) & INTERPOLATE_MASK;                                  \
    m5 = (n+2) & INTERPOLATE_MASK;                                  \
    m6 = (n+3) & INTERPOLATE_MASK;                                  \
    d1 = q - m1;                                                    \
    d2 = q - m2;                                                    \
    d3 = q - m3;                                                    \
    d4 = q - m4;                                                    \
    d5 = q - m5;                                                    \
    d6 = q - m6;                                                    \
    d16 = d1*d6;                                                    \
    d25 = d2*d5;                                                    \
    d34 = d3*d4;                                                    \
    s1 = (TABLE[m4]*d3-TABLE[m3]*d4)*d16*d25;                       \
    s2 = (TABLE[m5]*d2-TABLE[m2]*d5)*d34*d16;                       \
    s3 = (TABLE[m6]*d1-TABLE[m1]*d6)*d25*d34;                       \
    Y = (10*s1-5*s2+s3)/120;                                        \
}

#define INTERPOLATE_ORDER8(X,Y,TABLE,XMIN,INVDX,LOG2SIZE)           \
{                                                                   \
    double q, d1, d2, d3, d4, d5, d6, d7, d8, d18, d27, d36, d45,   \
           s1, s2, s3, s4;                                          \
    unsigned int n, m1, m2, m3, m4, m5, m6, m7, m8;                 \
    q = (X-(XMIN))*(INVDX);                                         \
    n = floor(q);                                                   \
    m1 = (n-3) & INTERPOLATE_MASK;                                  \
    m2 = (n-2) & INTERPOLATE_MASK;                                  \
    m3 = (n-1) & INTERPOLATE_MASK;                                  \
    m4 = (n-0) & INTERPOLATE_MASK;                                  \
    m5 = (n+1) & INTERPOLATE_MASK;                                  \
    m6 = (n+2) & INTERPOLATE_MASK;                                  \
    m7 = (n+3) & INTERPOLATE_MASK;                                  \
    m8 = (n+4) & INTERPOLATE_MASK;                                  \
    d1 = q - m1;                                                    \
    d2 = q - m2;                                                    \
    d3 = q - m3;                                                    \
    d4 = q - m4;                                                    \
    d5 = q - m5;                                                    \
    d6 = q - m6;                                                    \
    d7 = q - m7;                                                    \
    d8 = q - m8;                                                    \
    d18 = d1*d8;                                                    \
    d27 = d2*d7;                                                    \
    d36 = d3*d6;                                                    \
    d45 = d4*d5;                                                    \
    s1 = (TABLE[m5]*d4-TABLE[m4]*d5)*d18*d27*d36;                   \
    s2 = (TABLE[m6]*d3-TABLE[m3]*d6)*d45*d18*d27;                   \
    s3 = (TABLE[m7]*d2-TABLE[m2]*d7)*d36*d45*d18;                   \
    s4 = (TABLE[m8]*d1-TABLE[m1]*d8)*d27*d36*d45;                   \
    Y = (-35*s1+21*s2-7*s3+s4)/5040;                                \
}
